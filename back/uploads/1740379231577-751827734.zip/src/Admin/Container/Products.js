import React, { useEffect, useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { DataGrid } from '@mui/x-data-grid';
import { object, string } from 'yup';
import { useFormik } from 'formik';
import { FormControl, IconButton, InputLabel, MenuItem, Select } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useDispatch, useSelector } from 'react-redux';
import { addProduct, deleteProduct, editProduct, getProduct } from '../../redux/slice/Product.slice';


function Products(props) {
    const [open, setOpen] = useState(false);
    const [categories, setCategories] = useState([]);
    const [productdata, setproductData] = useState([]);
    const [productedit, setproductedit] = useState(null);
    const [subCategories, setsubCategories] = useState([]);

    const getproductdata = async () => {
        // const response = await fetch('http://localhost:1012/product');
        // const data = await response.json();
        // setproductData(data);
        dispatch(getProduct());
    }

    const dispatch = useDispatch();


    const product = useSelector (
        state => state.product
    )

    console.log(product.product);

    useEffect(() => {
        // Fetch categories from API
        fetchCategories();
        fetchsubCategories();
        getproductdata();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await fetch(`http://localhost:1012/category`);
            if (!response.ok) {
                throw new Error('Failed to fetch categories');
            }
            const data = await response.json();
            setCategories(data); // Update state with fetched categories
        } catch (error) {
            console.error('Error fetching categories:', error);
            // Optionally handle error (e.g., show error message)
        }
    };

    const fetchsubCategories = async () => {
        try {
            const response = await fetch(`http://localhost:1012/subcategory`);
            if (!response.ok) {
                throw new Error('Failed to fetch categories');
            }
            const data = await response.json();
            setsubCategories(data); // Update state with fetched categories
        } catch (error) {
            console.error('Error fetching categories:', error);
            // Optionally handle error (e.g., show error message)
        }
    };

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        resetForm();
        setproductedit(null);
    };

    // table
    const columns = [
        {
            field: 'categoryid',
            headerName: 'Category',
            width: 150,
            renderCell: (params) => {
                const categoryId = params.row.categoryid;
                console.log(categoryId);

                const categoryName = categories.find((category) => category.id === categoryId)?.name;
                return categoryName;
            }
        },
        {
            field: 'subcatid',
            headerName: 'Category',
            width: 170,
            renderCell: (params) => {
                const subcategoryId = params.row.subcatid;
                console.log(subcategoryId);

                const categoryName = subCategories.find((subcategory) => subcategory.id === subcategoryId)?.subname;
                return categoryName;
            }
        },
        { field: 'productName', headerName: 'Name', width: 150 },
        { field: 'productDesc', headerName: 'Description', width: 900 },
        { field: 'price', headerName: 'Price', width: 100 },
        {    headerName: 'Action',
            width: 130,
            renderCell: (params) => {
                return (
                    <>
                        <IconButton color="primary" onClick={() => handleDelete(params.row)} >
                            <DeleteIcon />
                        </IconButton>
                        <IconButton color="primary" onClick={() => handleEdit(params.row)} >
                            <EditIcon />
                        </IconButton>
                    </>
                )
            }
        },
    ];

    const handleEdit = (v) => {
        console.log(v)
        handleClickOpen();
        setValues(v);
        setproductedit(v);
    }

    const handleDelete = async (v) => {
        dispatch(deleteProduct(v));
        console.log(v);
        // try {
            // const response = await fetch(`http://localhost:1012/product/${v.id}`, {
            //     method: 'DELETE',
            // });

        //     if (response.ok) {
        //         // Remove the deleted category from the state
        //         setproductData((prev) => prev.filter((subcategory) => subcategory.id !== v.id));
        //     } else {
        //         console.error('Failed to delete subcategory');
        //     }
        // } catch (error) {
        //     console.error('Error deleting subcategory:', error);
        // }
    }

    // yup validation
    let productSchema = object({
        productName: string().required("enter product name !!"),
        productDesc: string().required("enter proper description for product !!"),
        price: string().required("enter proper price !!")
    });


    const addproduct = async (v) => {
        dispatch(addProduct(v));
        // console.log(v)
        // const response = await fetch("http://localhost:1012/product", {
        //     method: "POST",
        //     headers: {
        //         "Content-Type": "application/json"
        //     },
        //     body: JSON.stringify(v)
        // })
        // const data = await response.json();
        // console.log(data);

        // // setsubCatData ((prve) => prve.concat(data));
        // setproductData((prev) => [...prev, data]);
        // handleClose();
    }

    const editproduct = async (v) => {
        dispatch(editProduct(v));
        console.log(v);
        // try {
        //     const response = await fetch(`http://localhost:1012/product/${v.id}`, {
        //         method: 'PUT',
        //         headers: {
        //             "Content-Type": "application/json"
        //         },
        //         body: JSON.stringify(v)
        //     })
        //     const data = await response.json();
        //     console.log(data);
        //     setproductData((prev) => prev.map((v) => v.id === data.id ? data : v));


        // } catch (error) {
        //     console.error("Error Edit Subcategory", error)
        // }
    }

    // formik 
    const formik = useFormik({
        initialValues: {
            categoryid: '',
            subcatid:'',
            productName: '',
            price: '',
            productDesc:''
        },
        validationSchema: productSchema,
        onSubmit: (values, { resetForm }) => {
            console.log(values);
            if (productedit) {
                editproduct(values);

            } else {
                addproduct(values);
            }
            // addproduct(values);
            handleClose();
            resetForm();

        },
    });

    const { handleSubmit, handleBlur, handleChange, errors, values, touched, resetForm, setValues } = formik;

    return (
        <>
            <h4>Product</h4>

            <div className='d-flex justify-content-end'>
                <Button variant="contained" className='mb-2' startIcon={<AddIcon />} onClick={handleClickOpen}>
                    Product
                </Button>
            </div>

            <Dialog
                open={open}
                onClose={handleClose}

            >
                <DialogTitle>Add Subcategory</DialogTitle>
                <DialogContent>
                    <DialogContentText className='mb-3'>
                        Describe the specific focus or purpose of the subcategory in one sentence.
                    </DialogContentText>
                    <form action="" onSubmit={handleSubmit}>
                        <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">Category</InputLabel>

                            <Select
                                labelId="selectcat-label"
                                id="categoryid"
                                name="categoryid"
                                label="Category"
                                className="mb-3"
                                value={values.categoryid}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                error={errors.categoryid && touched.categoryid}
                                helperText={errors.categoryid && touched.categoryid ? errors.categoryid : ''}
                            >
                                {categories.map(category => (
                                    <MenuItem key={category.id} value={category.id}>{category.name}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">Subcategory</InputLabel>
                            <Select
                            labelId="selectcat-label"
                            id='subcatid'
                            name="subcatid"
                            label="Subcategory"
                            value={values.subcatid}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.subcatid && touched.subcatid}
                            helperText={errors.subcatid && touched.subcatid ? errors.subcatid : ''}
                            >
                                {
                                    subCategories.filter((v) => {
                                        return v.categoryid === values.categoryid
                                    }).map(subcategory => (
                                        <MenuItem key={subcategory.id} value={subcategory.id}>{subcategory.subname}</MenuItem>
                                        ))
                                }                             
                            </Select>
                        </FormControl>
                        <TextField
                            margin="dense"
                            id="productName"
                            name="productName"
                            label="Name"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.productName}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.productName && touched.productName}
                            helperText={errors.productName && touched.productName ? errors.productName : ''}
                        />
                        <TextField
                            margin="dense"
                            id="price"
                            name="price"
                            label="Price"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.price}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.price && touched.price}
                            helperText={errors.price && touched.price ? errors.price : ''}
                        />
                        <TextField
                            margin="dense"
                            id="productDesc"
                            name="productDesc"
                            label="Description"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.productDesc}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.productDesc && touched.productDesc}
                            helperText={errors.productDesc && touched.productDesc ? errors.productDesc : ''}
                        />
                        
                        <DialogActions>
                            <Button onClick={handleClose}>Cancel</Button>
                            <Button type="submit">{productedit ? 'Update' : 'Add'}</Button>

                        </DialogActions>
                    </form >
                </DialogContent>
            </Dialog>

            {/* table  */}
            <div >
                <DataGrid
                    rows={product.product}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: { page: 0, pageSize: 5 },
                        },
                    }}
                    pageSizeOptions={[5, 11]}
                    checkboxSelection
                />
            </div>
        </>
    );
}

export default Products;