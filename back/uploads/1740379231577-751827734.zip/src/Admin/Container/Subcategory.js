import React, { useEffect, useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { DataGrid } from '@mui/x-data-grid';
import { object, string } from 'yup';
import { useFormik } from 'formik';
import { FormControl, IconButton, InputLabel, MenuItem, Select } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useDispatch, useSelector } from 'react-redux';
import { AddSubcategory, DeleteSubcategory, getSubcategory, UpdateSubcategory } from '../../redux/action/Subcategory.action';

function Subcategory(props) {

    const [open, setOpen] = useState(false);
    const [categories, setCategories] = useState([]);
    const [subCatData , setsubCatData] = useState([]);
    const [subedit, setsubedit] = useState(null);

    const dispetch = useDispatch();

    const getsubCatData = async () => {
        dispetch(getSubcategory());        
    }
    const subcategory = useSelector (state => state.subcategory);
    console.log(subcategory.subcategory);

    useEffect(() => {
        // Fetch categories from API
        fetchCategories();
        getsubCatData();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await fetch(`http://localhost:1012/category`);
            if (!response.ok) {
                throw new Error('Failed to fetch categories');
            }
            const data = await response.json();
            setCategories(data); // Update state with fetched categories
        } catch (error) {
            console.error('Error fetching categories:', error);
            // Optionally handle error (e.g., show error message)
        }
    };

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
         resetForm();
         setsubedit(null);
    };

    // table
    const columns = [
        { field: 'categoryid', 
            headerName: 'Category',  
            width: 150,
            renderCell: (params) => {
                const categoryId = params.row.categoryid;
                console.log(categoryId);

                const categoryName = categories.find((category) => category.id === categoryId)?.name;
                return categoryName;
              }
        },
        { field: 'subname', headerName: 'Name', width: 130 },
        { field: 'subdesc', headerName: 'Description', width: 1000 },
        {
            headerName: 'Action',
            width: 130,
            renderCell: (params) => {
                return (
                    <>
                        <IconButton color="primary" onClick={() => handleDelete(params.row)} >
                            <DeleteIcon />
                        </IconButton>
                        <IconButton color="primary" onClick={() => handleEdit(params.row)} >
                            <EditIcon />
                        </IconButton>
                    </>
                )
            }
        },
    ];    

    const handleEdit = (v) => {
        console.log(v)
        handleClickOpen();
        setValues(v);
        setsubedit(v);
    }

    const handleDelete = async (v) => {
        console.log(v);
        dispetch(DeleteSubcategory(v));
        // try {
        //     const response = await fetch(`http://localhost:1012/subcategory/${v.id}`, {
        //         method: 'DELETE',
        //     });

        //     if (response.ok) {
        //         // Remove the deleted category from the state
        //         setsubCatData((prev) => prev.filter((subcategory) => subcategory.id !== v.id));
        //     } else {
        //         console.error('Failed to delete subcategory');
        //     }
        // } catch (error) {
        //     console.error('Error deleting subcategory:', error);
        // }
    }

    // yup validation
    let subcategorySchema = object({
        subname: string().required("enter subcategory name !!"),
        subdesc: string().required("enter proper description for category !!")
    });


    const addsubCat = async (v) => {
        console.log(v)
        dispetch(AddSubcategory(v));
        // const response = await fetch ("http://localhost:1012/subcategory",{
        //     method: "POST",
        //     headers: {
        //         "Content-Type": "application/json"
        //         },
        //         body: JSON.stringify(v)
        // })
        // const data = await response.json();
        // console.log(data);

        // setsubCatData ((prve) => prve.concat(data));
        // setsubCatData((prev) => [...prev, data]);
        // handleClose();
    }

    const editSubCat = async (v) => {
        console.log(v);
        dispetch(UpdateSubcategory(v));
        // try {
            // const response = await fetch(`http://localhost:1012/subcategory/${v.id}`, {
            //     method: 'PUT',
            //     headers: {
            //         "Content-Type": "application/json"
            //         },
            //         body: JSON.stringify(v)
            // })
            // const data = await response.json();
        //     console.log(data);
        //     setsubCatData((prev) => prev.map((v) => v.id === data.id ? data : v));

            
        // } catch (error) {
        //     console.error("Error Edit Subcategory", error)
        // }        
    }

    // formik 
    const formik = useFormik({
        initialValues: {
            categoryid: '',
            subname: '',
            subdesc: ''
        },
        validationSchema: subcategorySchema,
        onSubmit: (values, { resetForm }) => {
            console.log(values);
            if (subedit) {
                editSubCat(values);
                
            }else{
                addsubCat(values);
            }

            handleClose();
            resetForm();

        },
    });

    const { handleSubmit, handleBlur, handleChange, errors, values, touched, resetForm , setValues} = formik;

    return (
        <>
            <h4>Subcategory</h4>

            <div className='d-flex justify-content-end'>
                <Button variant="contained" className='mb-2' startIcon={<AddIcon />} onClick={handleClickOpen}>
                    Subcategory
                </Button>
            </div>

            <Dialog
                open={open}
                onClose={handleClose}
                
            >
                <DialogTitle>Add Subcategory</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Describe the specific focus or purpose of the subcategory in one sentence.
                    </DialogContentText>
                    <form action="" onSubmit={handleSubmit}>
                        <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">Category</InputLabel>
                           
                            <Select
                                labelId="selectcat-label"
                                id="categoryid"
                                name="categoryid"
                                label="Category"
                                value={values.categoryid}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                error={errors.categoryid && touched.categoryid}
                                helperText={errors.categoryid && touched.categoryid ? errors.categoryid : ''}
                            >
                                {categories.map(category => (
                                    <MenuItem key={category.id} value={category.id}>{category.name}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <TextField
                            margin="dense"
                            id="subname"
                            name="subname"
                            label="Subcategory Name"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.subname}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.subname && touched.subname}
                            helperText={errors.subname && touched.subname ? errors.subname : ''}
                        />
                        <TextField
                            margin="dense"
                            id="subdesc"
                            name="subdesc"
                            label="Subcategory Description"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.subdesc}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.subdesc && touched.subdesc}
                            helperText={errors.subdesc && touched.subdesc ? errors.subdesc : ''}
                        />
                       
                        <DialogActions>
                            <Button onClick={handleClose}>Cancel</Button>
                            <Button type="submit">{subedit ? 'Update' : 'Add'}</Button>

                        </DialogActions>
                    </form >
                </DialogContent>
            </Dialog>

            {/* table  */}
            <div>
                <DataGrid
                    rows={subcategory.subcategory}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: { page: 0, pageSize: 5 },
                        },
                    }}
                    pageSizeOptions={[5, 11]}
                    checkboxSelection
                />
            </div>

        </>
    );
}

export default Subcategory;