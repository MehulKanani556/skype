import React, { useEffect, useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { DataGrid } from "@mui/x-data-grid";
import { object, string } from "yup";
import { useFormik } from "formik";
import { IconButton } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { useDispatch, useSelector } from "react-redux";
import { addCoupon, deleteCoupon, editCoupon, getCoupon } from "../../redux/slice/Coupon.slice";

function Coupon(props) {
    const [open, setOpen] = useState(false);
    const [EditCoupon, setEditCoupon] = useState(null);

    const dispatch = useDispatch();

    const getCouponData = async () => {
        dispatch(getCoupon());
        // dispatch(getCoupon());
        // try {
        //     const response = await fetch("http://localhost:1012/coupon");
        //     const data = await response.json();
        //     setCoupon(data); // Update local state with fetched data
        // } catch (error) {
        //     console.log(error.message);
        // }
    };

    const coupons = useSelector((state) => state.coupon.coupon); 
    console.log(coupons);        
    

    useEffect(() => {
        getCouponData();
    }, []);

    const handleClickOpen = (v) => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        resetForm();
        setEditCoupon(null);
    };

    const handleDelete = async (v) => {
        console.log(v);
        dispatch(deleteCoupon(v));
        // try {
        //     const response = await fetch(`http://localhost:1012/coupon/${v.id}`, {
        //         method: 'DELETE',
        //     });

        //     if (response.ok) {
        //         // Update local state to remove the deleted coupon
        //         setCoupon((prev) => prev.filter((category) => category.id !== v.id));
        //     } else {
        //         console.error("Failed to delete category");
        //     }
        // } catch (error) {
        //     console.error("Error deleting category:", error);
        // }
    };

    const handleEdit = (v) => {
        console.log(v);
        handleClickOpen();
        setValues(v);
        setEditCoupon(v);
    };

    const columns = [
        { field: "couponCode", headerName: "Code", width: 150 },
        { field: "discountPercentage", headerName: "Discount", width: 1400 },
        {
            headerName: "Action",
            width: 130,
            renderCell: (params) => {
                return (
                    <>
                        <IconButton
                            color="primary"
                            onClick={() => handleDelete(params.row)}
                        >
                            <DeleteIcon />
                        </IconButton>
                        <IconButton color="primary" onClick={() => handleEdit(params.row)}>
                            <EditIcon />
                        </IconButton>
                    </>
                );
            },
        },
    ];

    // yup validation
    let couponSchema = object({
        couponCode: string().required("enter coupon code !!"),
        discountPercentage: string().required(
            "enter proper discount for this coupon !!"
        ),
    });

    const editCouponData = async (v) => {
        console.log(v);
        dispatch(editCoupon(v));
        // try {
        //     const response = await fetch(`http://localhost:1012/coupon/${v.id}`, {
        //         method: "PUT",
        //         headers: {
        //             "Content-Type": "application/json",
        //         },
        //         body: JSON.stringify(v),
        //     });
        //     const data = await response.json();

        //     setCoupon((prev) =>
        //         prev.map((item) => (item.id === data.id ? data : item))
        //     );
        // } catch (error) {
        //     console.error("Error editing category:", error);
        // }
    };

    const addCat = async (v) => {
        dispatch(addCoupon(v));
        // const response = await fetch("http://localhost:1012/coupon", {
        //     method: "POST",
        //     headers: {
        //         "Content-Type": "application/json",
        //     },
        //     body: JSON.stringify(v),
        // });
        // const data = await response.json();
        // console.log(data);

        // setcatDate((prev) => prev.concat(data));
    };

    // formik
    const formik = useFormik({
        initialValues: {
            couponCode: "",
            discountPercentage: "",
        },
        validationSchema: couponSchema,
        onSubmit: (values, { resetForm }) => {
            // alert(JSON.stringify(values, null, 2));
            if (EditCoupon) {
                editCouponData(values);
            } else {
                addCat(values);
            }

            handleClose();
            resetForm();
        },
    });

    const { handleSubmit, handleBlur,  handleChange, errors,values,touched,setValues, resetForm,} = formik;

    return (
        <>
            <h4>Coupon</h4>

            <div className="d-flex justify-content-end">
                <Button
                    variant="contained"
                    className="mb-2"
                    startIcon={<AddIcon />}
                    onClick={handleClickOpen}
                >
                    Coupon
                </Button>
            </div>

            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Add Coupon</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Category form designed for streamlined data collection and
                        organization.
                    </DialogContentText>
                    <form action="" onSubmit={handleSubmit}>
                        <TextField
                            margin="dense"
                            id="couponCode" 
                            name="couponCode" 
                            label="Coupon Code" 
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.couponCode} 
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.couponCode && touched.couponCode} 
                            helperText={
                                errors.couponCode && touched.couponCode ? errors.couponCode : ""
                            } 
                        />
                        <TextField
                            margin="dense"
                            id="discountPercentage" 
                            name="discountPercentage" 
                            label="Discount Percentage" 
                            type="number" 
                            fullWidth
                            variant="standard"
                            value={values.discountPercentage} 
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.discountPercentage && touched.discountPercentage} 
                            helperText={
                                errors.discountPercentage && touched.discountPercentage
                                    ? errors.discountPercentage
                                    : ""
                            } 
                        />
                        <DialogActions>
                            <Button onClick={handleClose}>Cancel</Button>
                            <Button type="submit">{EditCoupon ? "Update" : "Add"}</Button>
                        </DialogActions>
                    </form>
                </DialogContent>
            </Dialog>
            {/* table */}
            <div>
                <DataGrid
                    rows={coupons}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: { page: 0, pageSize: 5 },
                        },
                    }}
                    pageSizeOptions={[5, 10]}
                    checkboxSelection
                />
            </div>
        </>
    );
}

export default Coupon;
