// import React, { useEffect, useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { getcheck } from '../../redux/slice/Checkout.slice';
// import EditIcon from '@mui/icons-material/Edit';
// import { IconButton } from '@mui/material';
// import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
// import { DataGrid } from '@mui/x-data-grid';
// import { Modal, Button } from 'react-bootstrap'; // Import Bootstrap Modal
// import { getProduct } from '../../redux/slice/Product.slice';
// import { updateOrderStatus } from '../../redux/slice/Checkout.slice'; // Import the action to update order status

// function Order(props) {
//     const dispatch = useDispatch();
//     const [rows, setRows] = useState([]);
//     const [showModal, setShowModal] = useState(false); // State for modal open/close
//     const [selectedOrder, setSelectedOrder] = useState(null); // State to hold the selected order
//     const [isEditMode, setIsEditMode] = useState(false); // State to determine if in edit mode


//     const handleCloseModal = () => {
//         setShowModal(false); // Close the modal
//         setSelectedOrder(null); // Reset selected order
//         setIsEditMode(false); // Reset edit mode
//     };

//     useEffect(() => {
//         dispatch(getcheck());
//         dispatch(getProduct());
//     }, [dispatch]);

//     const Orders = useSelector((state) => state.checkout.checkout);
//     const product = useSelector((state) => state.product.product);

//     const handleShow = (data, editMode = false) => {
//         console.log(data, Orders);

//         const fData = Orders.find((v) => v.id === data.id);

//         console.log(fData);


//         setSelectedOrder(fData); // Set the selected order
//         setIsEditMode(editMode); // Set the mode (edit or view)
//         setShowModal(true); // Open the modal
//     };


//     useEffect(() => {
//         if (Orders.length > 0) {
//             const formattedRows = Orders.map((order) => {
//                 const productIds = order.cart.map((item) => item.pid);
//                 const totalQuantity = order.cart.reduce((sum, item) => sum + item.qty, 0);

//                 const productNames = productIds.map((id) => {
//                     const matchedProduct = product.find((prod) => prod.id === id);
//                     return matchedProduct ? matchedProduct.productName : 'Unknown Product';
//                 }).join(', ');

//                 return {
//                     id: order.id,
//                     name: order.billing_details.name,
//                     email: order.billing_details.email,
//                     productIds: productNames,
//                     quantity: totalQuantity,
//                     totalAmount: order.total_amt,
//                     paymentStatus: order.billing_details.payment_method ? 'Unpaid' : 'Paid',
//                     Status: order.Status,
//                 };
//             });

//             setRows(formattedRows);
//         }
//     }, [Orders, product]);

// const columns = [
//     { field: "id", headerName: "Order ID", width: 150 },
//     { field: "name", headerName: "Customer Name", width: 150 },
//     { field: "email", headerName: "Email", width: 200 },
//     { field: "productIds", headerName: "Product IDs", width: 300 },
//     { field: "quantity", headerName: "Total Quantity", type: "number", width: 150 },
//     { field: "totalAmount", headerName: "Total Amount", type: "number", width: 150 },
//     { field: "paymentStatus", headerName: "Payment Status", width: 150 },
//     { field: "Status", headerName: "Order Status", width: 150 },
//     {
//         headerName: "Action",
//         width: 150,
//         renderCell: (params) => {
//             return (
//                 <>
//                     <IconButton color="primary" onClick={() => handleShow(params.row, true)} >
//                         <EditIcon />
//                     </IconButton>
//                     <IconButton color="primary" onClick={() => handleShow(params.row)} >
//                         <RemoveRedEyeIcon />
//                     </IconButton>
//                 </>
//             );
//         },
//     },
// ];

//     const handleEditSubmit = async (e) => {
//         e.preventDefault();
//         if (selectedOrder) {
//             console.log("selectedOrder", selectedOrder);

//             dispatch(updateOrderStatus(selectedOrder));

//             handleCloseModal();
//         }
//     };

//     return (
//         <>
//             <h4>Orders</h4>
//             <div>
//                 <DataGrid
//                     rows={rows}
//                     columns={columns}
//                     initialState={{
//                         pagination: {
//                             paginationModel: { page: 0, pageSize: 5 },
//                         },
//                     }}
//                     pageSizeOptions={[5, 10]}
//                     checkboxSelection
//                 />
//             </div>

//             <Modal show={showModal} onHide={handleCloseModal} centered>
//                 <Modal.Header closeButton>
//                     <Modal.Title>{isEditMode ? "Edit Order Status" : "Order Details"}</Modal.Title>
//                 </Modal.Header>
//                 <Modal.Body>
//                     {selectedOrder && (
//                         <div className="container mt-3">
//                             <h5>Order ID: {selectedOrder.id}</h5>
//                             <div><strong>Email:</strong> {selectedOrder.billing_details.email}</div>
//                             <div><strong>Total Quantity:</strong> {selectedOrder.cart.reduce((total, item) => total + item.qty, 0)}</div>
//                             <div><strong>Total Amount:</strong> ${selectedOrder.total_amt.toFixed(2)}</div>

//                             <h6 className="mt-4">Products:</h6>
//                             <div className="row">
//                                 {selectedOrder.cart.map((item) => {
//                                     const product = product.find(prod => prod.id === item.pid);
//                                     return (
//                                         <div className="col-md-4 mb-3" key={item.pid}>
//                                             <div className="card border-primary">
//                                                 <div className="card-body">
//                                                     <h5 className="card-title">{product ? product.productName : "Unknown Product"}</h5>
//                                                     <p className="card-text"><strong>Quantity:</strong> {item.qty}</p>
//                                                     <p className="card-text"><strong>Price:</strong> ${product ? product.price.toFixed(2) : "0.00"}</p>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                     );
//                                 })}
//                             </div>

//                             {!isEditMode && (
//                                 <div><strong>Order Status:</strong> {selectedOrder.Status}</div>
//                             )}

//                             {isEditMode && (
//                                 <div className="mb-3">
//                                     <label><strong>Order Status:</strong></label>
//                                     <select
//                                         className="form-control"
//                                         value={selectedOrder.Status}
//                                         onChange={(e) => setSelectedOrder({ ...selectedOrder, Status: e.target.value })}
//                                     >
//                                         <option value="pending">Pending</option>
//                                         <option value="accept">Accept</option>
//                                         <option value="reject">Reject</option>
//                                         <option value="transit">Transit</option>
//                                         <option value="delivered">Delivered</option>
//                                         <option value="cancel">Cancel</option>
//                                     </select>
//                                 </div>
//                             )}
//                         </div>
//                     )}
//                 </Modal.Body>
//                 <Modal.Footer>
//                     <Button variant="secondary" onClick={handleCloseModal}>
//                         Close
//                     </Button>
//                     {isEditMode && (
//                         <Button type="submit" variant="primary" onClick={handleEditSubmit}>
//                             Save Changes
//                         </Button>
//                     )}
//                 </Modal.Footer>
//             </Modal>
//         </>
//     );
// }

// export default Order;
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getcheck } from '../../redux/slice/Checkout.slice';
import EditIcon from '@mui/icons-material/Edit';
import { IconButton } from '@mui/material';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import { DataGrid } from '@mui/x-data-grid';
import { Modal, Button } from 'react-bootstrap';
import { getProduct } from '../../redux/slice/Product.slice';
import { updateOrderStatus } from '../../redux/slice/Checkout.slice';

function Order() {
    const dispatch = useDispatch();
    const [rows, setRows] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedOrder, setSelectedOrder] = useState(null);
    const [isEditMode, setIsEditMode] = useState(false);

    // Function to close the modal
    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedOrder(null);
        setIsEditMode(false);
    };

    // Fetch orders and products on component mount
    useEffect(() => {
        dispatch(getcheck());
        dispatch(getProduct());
    }, [dispatch]);

    const Orders = useSelector((state) => state.checkout.checkout);
    const products = useSelector((state) => state.product.product); // Renamed to products for clarity

    // Function to show modal with selected order details
    const handleShow = (data, editMode = false) => {
        const foundOrder = Orders.find((v) => v.id === data.id);
        setSelectedOrder(foundOrder);
        setIsEditMode(editMode);
        setShowModal(true);
    };

    // Formatting order data for the DataGrid
    useEffect(() => {
        // Check if there are any orders
        if (Orders.length > 0) {
            const formattedRows = Orders.map((order) => {
                // Get the product IDs from the cart items
                const productIds = order.cart.map((item) => item.pid);
    
                // Calculate the total quantity of items in the cart
                const totalQuantity = order.cart.reduce((sum, item) => sum + item.qty, 0);
    
                // Get the product names using the product IDs
                const productNames = productIds.map((id) => {
                    // Find the matching product in the products array
                    const matchedProduct = products.find((prod) => prod.id === id);
                    // Return the product name or 'Unknown Product' if not found
                    return matchedProduct ? matchedProduct.productName : 'Unknown Product';
                }).join(', '); // Join product names into a single string
    
                // Return the formatted order data
                return {
                    id: order.id,
                    name: order.billing_details.name,
                    email: order.billing_details.email,
                    productIds: productNames, // Use the product names instead of IDs
                    quantity: totalQuantity,
                    totalAmount: order.total_amt,
                    paymentStatus: order.billing_details.payment_method ? 'Unpaid' : 'Paid',
                    Status: order.Status,
                };
            });
    
            // Update the state with the formatted rows
            setRows(formattedRows);
        }
    }, [Orders, products]); // Make sure to include products in the dependency array
    

    // DataGrid columns definition
    const columns = [
        { field: "id", headerName: "Order ID", width: 150 },
        { field: "name", headerName: "Customer Name", width: 150 },
        { field: "email", headerName: "Email", width: 200 },
        { field: "productIds", headerName: "Product IDs", width: 300 },
        { field: "quantity", headerName: "Total Quantity", type: "number", width: 150 },
        { field: "totalAmount", headerName: "Total Amount", type: "number", width: 150 },
        { field: "paymentStatus", headerName: "Payment Status", width: 150 },
        { field: "Status", headerName: "Order Status", width: 150 },
        {
            headerName: "Action",
            width: 150,
            renderCell: (params) => {
                return (
                    <>
                        <IconButton color="primary" onClick={() => handleShow(params.row, true)} >
                            <EditIcon />
                        </IconButton>
                        <IconButton color="primary" onClick={() => handleShow(params.row)} >
                            <RemoveRedEyeIcon />
                        </IconButton>
                    </>
                );
            },
        },
    ];

    // Function to handle order status updates
    const handleEditSubmit = async (e) => {
        e.preventDefault();
        if (selectedOrder) {
            dispatch(updateOrderStatus(selectedOrder));
            handleCloseModal();
        }
    };

    return (
        <>
            <h4>Orders</h4>
            <div>
                <DataGrid
                    rows={rows}
                    columns={columns}
                    pageSizeOptions={[5, 10]}
                    checkboxSelection
                />
            </div>

            <Modal  show={showModal} onHide={handleCloseModal} centered>
                <Modal.Header closeButton>
                    <Modal.Title>{isEditMode ? "Edit Order Status" : "Order Details"}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {selectedOrder && (
                        <div className="container mt-3">
                            <h5 style={{ color: '#757575' }}>Order ID: {selectedOrder.id}</h5>
                            <div><strong>Email:</strong> {selectedOrder.billing_details.email}</div>
                            <div><strong>Total Quantity:</strong> {selectedOrder.cart.reduce((total, item) => total + item.qty, 0)}</div>
                            <div><strong>Total Amount:</strong> ${selectedOrder.total_amt.toFixed(2)}</div>

                            <h6 className="mt-4">Products:</h6>
                            <div className="row">
                                {selectedOrder.cart.map((item) => {
                                    const product = products.find(prod => prod.id === item.pid);
                                    // Check if product exists and is valid before accessing its properties
                                    const productPrice = product ? Number(product.price) : 0; // Ensure price is a number

                                    return (
                                        <div className="col-md-4 mb-3" key={item.pid}>
                                            <div className="card border-primary">
                                                <div className="card-body">
                                                    <h5 className="card-title">{product ? product.productName : "Unknown Product"}</h5>
                                                    <p className="card-text"><strong>Quantity:</strong> {item.qty}</p>
                                                    <p className="card-text"><strong>Price:</strong> ${productPrice.toFixed(2)}</p> {/* Use the safe product price */}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {!isEditMode && (
                                <div><strong>Order Status:</strong> {selectedOrder.Status}</div>
                            )}

                            {isEditMode && (
                                <div className="mb-3">
                                    <label><strong>Order Status:</strong></label>
                                    <select
                                        className="form-control"
                                        value={selectedOrder.Status}
                                        onChange={(e) => setSelectedOrder({ ...selectedOrder, Status: e.target.value })}
                                    >
                                        <option value="pending">Pending</option>
                                        <option value="accept">Accept</option>
                                        <option value="reject">Reject</option>
                                        <option value="transit">Transit</option>
                                        <option value="delivered">Delivered</option>
                                        <option value="cancel">Cancel</option>
                                    </select>
                                </div>
                            )}
                        </div>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>
                        Close
                    </Button>
                    {isEditMode && (
                        <Button type="submit" variant="primary" onClick={handleEditSubmit}>
                            Save Changes
                        </Button>
                    )}
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default Order;