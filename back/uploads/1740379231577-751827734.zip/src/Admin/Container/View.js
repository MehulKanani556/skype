import { Button } from 'bootstrap';
import React from 'react';
import { useParams } from 'react-router-dom';

function View(props) {
    const { id } = useParams();
    console.log(id, "orderId"); // Log the order ID to the console

    return (
        <>
            <h4>Order Detail</h4>
            <div className='d-flex justify-content-end'>
                {/* <Button variant="contained" className='mb-2' startIcon={<AddIcon />} onClick={handleClickOpen}>
                    Category
                </Button> */}
                <select className='mb-2'> Status
                    <option value="pending">Pending</option>
                    <option value="accept">Accept</option>
                    <option value="Reject">Reject</option>
                    <option value="transist">Transist</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancel">Cancel</option>
                </select>
            </div>
        </>
    );
}

export default View;