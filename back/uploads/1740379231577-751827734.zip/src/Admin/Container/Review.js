import { Switch } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getReviews, updateStatus } from "../../redux/slice/Shopdetails.slice";

function Review(props) {
  const dispatch = useDispatch();
  const [checked, setChecked] = useState(false);
  const [rows, setRows] = useState([]);

  const handleChange = (data) => {
    console.log(data);
    dispatch(updateStatus(data))
    setChecked(data.id);
  };

  console.log(checked);
  
  useEffect(() => {
    dispatch(getReviews());
    // Dispatch the getReviews thunk
  }, [dispatch]);

  const reviews = useSelector((state) => state.reviews.reviews); 

  useEffect(() => {
    setRows(reviews); // Update rows with the fetched reviews
  }, [reviews]);

 const columns = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "name", headerName: "Name", width: 130 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "review", headerName: "Review", width: 250 },
    { field: "rating", headerName: "Rating", type: "number", width: 90 },
    { field: "productId", headerName: "Product ID", width: 100 },
    { field: "userId", headerName: "User ID", width: 100 },
    { field: "status", headerName: "Status", width: 100 },
    {
      headerName: "Action",
      width: 100,
      renderCell: (params) => {
        return (
          <Switch
              checked={params.row.status === 'active' ? true : false}
              onChange={() => handleChange(params.row)}
              inputProps={{ "aria-label": "controlled" }}
            />
        );
      },
    },
  ];

  const paginationModel = { page: 0, pageSize: 5 };

  return (
    <>
      <h4>Review</h4>
      <div>
        <DataGrid
          rows={rows}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 5 },
            },
          }}
          pageSizeOptions={[5, 10]}
          checkboxSelection
        />
      </div>
    </>
  );
}

export default Review;
