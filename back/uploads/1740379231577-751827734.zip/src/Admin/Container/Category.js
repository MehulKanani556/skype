import React, { useEffect, useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { DataGrid } from '@mui/x-data-grid';
import { object, string } from 'yup';
import { useFormik } from 'formik';
import { IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useDispatch, useSelector } from 'react-redux';
import { addCategorydata, deleteCategorydata, editCategorydata, getCategory } from '../../redux/slice/Category.slice';


function Category(props) {
    
    const [open, setOpen] = useState(false);
    const [catDate, setcatDate] = useState([]);
    const [editCategory, setEditCategory] = useState(null);

    const dispatch = useDispatch();

    const getcatData = async () => {
        dispatch(getCategory());
    }

    const category = useSelector (
        state => state.category
    )

    console.log(category.category);

    useEffect(() => {
        getcatData();
    }, [])

    const handleClickOpen = (v) => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        resetForm();
        setEditCategory(null);
    };

    const handleDelete = async (v) => {
        console.log(v);
        dispatch(deleteCategorydata(v));
        // try {
        //     const response = await fetch(`http://localhost:1012/category/${v.id}`, {
        //         method: 'DELETE',
        //     });

        //     if (response.ok) {
        //         // Remove the deleted category from the state
        //         setcatDate((prev) => prev.filter((category) => category.id !== v.id));
        //     } else {
        //         console.error('Failed to delete category');
        //     }
        // } catch (error) {
        //     console.error('Error deleting category:', error);
        // }
    }

    const handleEdit = (v) => {
        console.log(v);
        handleClickOpen();
        setValues(v);
        setEditCategory(v);

    }

    const columns = [
        { field: 'name', headerName: 'Name', width: 150 },
        { field: 'description', headerName: 'Description', width: 1400 },
        {
            headerName: 'Action',
            width: 130,
            renderCell: (params) => {
                return (
                    <>
                        <IconButton color="primary" onClick={() => handleDelete(params.row)} >
                            <DeleteIcon />
                        </IconButton>
                        <IconButton color="primary" onClick={() => handleEdit(params.row)} >
                            <EditIcon />
                        </IconButton>

                    </>
                )
            }
        },
    ];


    // yup validation
    let categorySchema = object({
        name: string().required("enter category name !!"),
        description: string().required("enter proper description for category !!")
    });

    const editCategoryData = async (v) => {
        
        console.log(v);
        dispatch(editCategorydata(v));
        // try {
        //     const response = await fetch(`http://localhost:1012/category/${v.id}`, {
        //         method: 'PUT',
        //         headers: {
        //             'Content-Type': 'application/json',
        //         },
        //         body: JSON.stringify(v),
        //     });
        //     const data = await response.json();

        //     console.log(data);

        //     setcatDate((prve) => prve.map((v) => v.id === data.id ? data : v))

        // } catch (error) {
        //     console.error('Error edit category:', error);

        // }
    }

    const addCat = async (v) => {
        dispatch(addCategorydata(v));
        // const response = await fetch("http://localhost:1012/category", {
        //     method: "POST",
        //     headers: {
        //         "Content-Type": "application/json",
        //     },
        //     body: JSON.stringify(v)
        // })
        // const data = await response.json();
        // console.log(data);

        // setcatDate((prev) => prev.concat(data));
    }


    // formik 
    const formik = useFormik({
        initialValues: {
            name: '',
            description: ''
        },
        validationSchema: categorySchema,
        onSubmit: (values , {resetForm}) => {
            // alert(JSON.stringify(values, null, 2));
            if (editCategory) {
                editCategoryData(values);
            }
            else {
                addCat(values);
            }

            handleClose();
            resetForm();

        },
    });

    const { handleSubmit, handleBlur, handleChange, errors, values, touched ,setValues ,resetForm } = formik;

    return (
        <>

            <h4>Category</h4>


            <div className='d-flex justify-content-end'>
                <Button variant="contained" className='mb-2' startIcon={<AddIcon />} onClick={handleClickOpen}>
                    Category
                </Button>
            </div>
            <Dialog
                open={open}
                onClose={handleClose}

            >
                <DialogTitle>Add Category</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Category form designed for streamlined data collection and organization.
                    </DialogContentText>
                    <form action="" onSubmit={handleSubmit}>
                        <TextField
                            margin="dense"
                            id="name"
                            name="name"
                            label="Category Name"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.name}                            
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.name && touched.name}
                            helperText={errors.name && touched.name ? errors.name : ''}
                        />
                        <TextField
                            margin="dense"
                            id="description"
                            name="description"
                            label="description"
                            type="text"
                            fullWidth
                            variant="standard"
                            value={values.description}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            error={errors.description && touched.description}
                            helperText={errors.description && touched.description ? errors.description : ''}
                        />
                        <DialogActions>
                            <Button onClick={handleClose}>Cancel</Button>
                            <Button type="submit">{editCategory ? 'Update' : 'Add'}</Button>

                        </DialogActions>
                    </form>
                </DialogContent>

            </Dialog>
            {/* table */}
            <div >
                <DataGrid
                    rows={category.category}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: { page: 0, pageSize: 5 },
                        },
                    }}
                    pageSizeOptions={[5, 10]}
                    checkboxSelection
                />
            </div>
        </>
    );
}

export default Category;