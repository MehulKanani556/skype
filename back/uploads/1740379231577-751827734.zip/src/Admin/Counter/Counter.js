import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { decrement, increment } from '../../redux/slice/Counter.slice';

function Counter(props) {
    const dispatch = useDispatch();

    const handleDec = () => {
        dispatch(decrement(1));
    }

    const handleInc = () => {
        dispatch(increment());
    }
    const counter = useSelector(state => state.counter );
    console.log(counter.count);
    return (
        <>
             <button onClick={handleDec}>-</button>
             <span>{counter.count}</span>
             <button onClick={handleInc}>+</button>            
        </>
    );
}

export default Counter;