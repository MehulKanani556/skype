// import { GET_PRODUCT } from "../ActionType";

// export const getproduct = () => async (dispatch) => {
//     try {
//         const response = await fetch('http://localhost:1012/product');
//         const data = await response.json();
    
//         dispatch({ type: GET_PRODUCT, payload : data });        
//     } catch (error) {
//         console.log(error.Message);
//     }
   
// }