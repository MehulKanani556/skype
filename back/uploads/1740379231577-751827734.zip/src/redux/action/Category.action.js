import { ADD_CATEGORY, DELETE_CATEGORY, GET_CATEGORY, UPDATE_CATEGORY } from "../ActionType";

export const getCategory = () => async (dispatch) => {
  try {
    const response = await fetch("http://localhost:1012/category");
    const data = await response.json();

    dispatch({ type: GET_CATEGORY, payload: data });
  } catch (error) {
    console.log(error.Message);
  }
};

export const addCategory = (v) => async (dispatch) => {
  try {
    const response = await fetch("http://localhost:1012/category", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(v),
    });
    const data = await response.json();
    dispatch({
      type: ADD_CATEGORY,
      payload: data,
    });
    // console.log(data);

    // setcatDate((prev) => prev.concat(data));
  } catch (error) {}
};

export const UpdateCategoryData = (v) => async (dispatch) => {
  try {
    const response = await fetch(`http://localhost:1012/category/${v.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(v),
    });
    const data = await response.json();
    dispatch({
      type: UPDATE_CATEGORY,
      payload: data,
    });

    // console.log(data);

    // setcatDate((prve) => prve.map((v) => v.id === data.id ? data : v))
  } catch (error) {
    console.error("Error edit category:", error);
  }
};



export const DeleteCategoryData = (v) => async (dispatch) => {
    try {
        const response = await fetch(`http://localhost:1012/category/${v.id}`, {
            method: 'DELETE',
            headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(v),
        });
        const data = await response.json();
        dispatch({ type: DELETE_CATEGORY, payload: data });

    } catch (error) {
        console.error('Error deleting category:', error);
    }
  };

// export const deleteCategory = (v) => async (dispatch) => {
//   try {
//     const response = await fetch(`http://localhost:1012/category/${v.id}`, {
//       method: "DELETE",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(v),
//     });
//     const data = await response.json();
//     dispatch({ type: DELETE_CATEGORY, payload: data });
//   } catch (error) {
//     console.error("Error deleting category:", error);
//   }
// };
