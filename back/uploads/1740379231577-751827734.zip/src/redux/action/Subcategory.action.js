import { ADD_SUBCATEGORY, DELETE_SUBCATEGORY, GET_SUBCATEGORY, UPDATE_SUBCATEGORY } from "../ActionType";

export const getSubcategory = () => async (dispatch) => {
    try {
        const response = await fetch('http://localhost:1012/subcategory');
        const data = await response.json();
        console.log(data);
        
       
        dispatch({type:GET_SUBCATEGORY , payload : data});
    } catch (error) {
        console.log(error.Massege);
    }

}


export const AddSubcategory = (v) => async (dispatch) => {
    try {
        const response = await fetch ("http://localhost:1012/subcategory",{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
                },
                body: JSON.stringify(v)
        })
        const data = await response.json();
        dispatch({type:ADD_SUBCATEGORY , payload : data});
    } catch (error) {
        console.log(error.Massege);
    }

}

export const UpdateSubcategory = (v) => async (dispatch) => {
    try {
        const response = await fetch(`http://localhost:1012/subcategory/${v.id}`, {
            method: 'PUT',
            headers: {
                "Content-Type": "application/json"
                },
                body: JSON.stringify(v)
        })
        const data = await response.json();
        dispatch({type:UPDATE_SUBCATEGORY , payload : data});
    } catch (error) {
        console.log(error.Massege);
    }

}

export const DeleteSubcategory = (v) => async (dispatch) => {
    try {
        const response = await fetch(`http://localhost:1012/subcategory/${v.id}`, {
            method: 'DELETE',
            headers: {
                "Content-Type": "application/json"
                },
                body: JSON.stringify(v)
        });
        const data = await response.json();
        
       
        dispatch({type:DELETE_SUBCATEGORY , payload : data});
    } catch (error) {
        console.log(error.Massege);
    }

}