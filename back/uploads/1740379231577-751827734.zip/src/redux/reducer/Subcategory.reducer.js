import { ADD_SUBCATEGORY, DELETE_SUBCATEGORY, GET_SUBCATEGORY, UPDATE_SUBCATEGORY } from "../ActionType";

const initialStates = {
  isloading: false,
  subcategory: [],
  error: null,
};

export const subcategoryReducer = (state = initialStates, action) => {
  console.log(action);

  switch (action.type) {
    case GET_SUBCATEGORY:
      return {
        isloading: false,
        subcategory: action.payload,
        error: null,
      };
    case ADD_SUBCATEGORY:
      return {
        isloading: false,
        subcategory: state.subcategory.concat(action.payload),
        error: null,
      };
      case UPDATE_SUBCATEGORY:
        return {
          isloading: false,
          subcategory: state.subcategory.map((v) => v.id === action.payload.id ? action.payload : v),
          error: null,
        };           
        case DELETE_SUBCATEGORY:
          return {
            isloading: false,
            subcategory: state.subcategory.filter((v) => v.id !== action.payload.id),
            error: null,
          }; 
    default:
      return state;
  }
};
