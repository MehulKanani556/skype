import { ADD_CATEGORY, DELETE_CATEGORY, GET_CATEGORY, UPDATE_CATEGORY } from "../ActionType";

const initialState = {
  isloading: false,
  category: [],
  error: null,
};

export const categoryReducer = (state = initialState, action) => {
  console.log(action);

  switch (action.type) {
    case GET_CATEGORY:
      return {
        isloading: false,
        category: action.payload,
        error: null,
      };
    case ADD_CATEGORY:
      return {
        isloading: false,
        category: state.category.concat(action.payload),
        error: null,
      };
    case UPDATE_CATEGORY:
      return {
        isloading: false,
        category: state.category.map((v) =>
          v.id === action.payload.id ? action.payload : v
        ),
        error: null,
      };
    case DELETE_CATEGORY:
      return {
        isloading: false,
        category: state.category.filter((v) => v.id !== action.payload.id),
        error: null,
      };
    default:
      return state;
  }
};
