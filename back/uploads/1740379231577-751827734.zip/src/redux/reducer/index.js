import { combineReducers } from "redux";
import { subcategoryReducer } from "./Subcategory.reducer";
import counterSlice from "../slice/Counter.slice";
import CategorySlice from "../slice/Category.slice";
import ProductSlice from "../slice/Product.slice";
import CartSlice from "../slice/Cart.slice";
import CouponSlice from "../slice/Coupon.slice";
import ShopdetailsSlice from "../slice/Shopdetails.slice";
import CheckoutSlice from "../slice/Checkout.slice";
import UserSlice from "../slice/User.slice";


export const rootReducer  = combineReducers({
    category : CategorySlice,
    subcategory : subcategoryReducer,
    product: ProductSlice,
    counter : counterSlice,
    cart: CartSlice,
    coupon: CouponSlice,
    reviews: ShopdetailsSlice,
    checkout : CheckoutSlice,
    user : UserSlice
})


