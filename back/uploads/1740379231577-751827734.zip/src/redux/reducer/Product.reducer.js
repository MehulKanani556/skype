// import { GET_PRODUCT } from "../ActionType";

// const initialState =  {
//     isloading: false, 
//     product:[],
//     error: null
// }

// export const productReducer = (state = initialState ,action) => {
//     console.log(action);
    

//     switch (action.type) {
//         case GET_PRODUCT:
//             return {
//                 isloading: false,
//                 product: action.payload,
//                 error: null,
//               };           
    
//         default:
//             break;
//     }
// }