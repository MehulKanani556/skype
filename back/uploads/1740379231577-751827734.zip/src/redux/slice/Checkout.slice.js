import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { BASE_URL } from "../../utils/baseURL";


const initialState = {
  isloading: false,
  checkout: [],
  error: null,
}

export const addcheck = createAsyncThunk(
  "checkout/addcheck",
  async (values) => {
    try {
      const response = await axios.post(BASE_URL + "checkout", values);
      return response.data;
      
    } catch (error) {
      return (error.message);
    }
  }
);


export const getcheck = createAsyncThunk(
  "check/getcheck",
  async () => {
    try {
      const response = await axios.get(BASE_URL + 'checkout');
      console.log(response);
      return response.data;

      // const response = await fetch('http://localhost:1012/checkout');
      // const data = await response.json();
      // return data;    
    } catch (error) {
      console.error("Error fetching orders:", error);
    }
  }
);


// Async thunk to update order status
export const updateOrderStatus = createAsyncThunk(
  'checkout/updateOrderStatus',
  async (data) => {
    const response = await axios.put(`${BASE_URL}checkout/${data.id}`, data); 
    return response.data; 
  });

const checkoutslice = createSlice({
  name: "checkout",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getcheck.fulfilled, (state, action) => {
        state.isloading = false;
        state.checkout = action.payload.filter(order => order.uid == '111');
        state.error = null;
      })
      .addCase(addcheck.fulfilled, (state, action) => {
        state.isloading = false;
        state.checkout = state.checkout.concat(action.payload);
        state.error = null;
      })
      .addCase(updateOrderStatus.fulfilled, (state, action) => {
        const index = state.checkout.findIndex(order => order.id === action.payload.id);
        if (index !== -1) {
          state.checkout[index] = action.payload; 
        }
      });
  },
});

export default checkoutslice.reducer;