import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
  isloading: false,
  user: [],
  error: null,
};

export const getuser = createAsyncThunk("user/getuser", async () => {
  try {
    const response = await fetch("http://localhost:1012/user");
    const data = await response.json();
    return data;
  } catch (error) {
    console.log(error.Message);
  }
});

export const adduserdata = createAsyncThunk("user/adduserdata", async (userData) => {
  
  try {
    const response = await fetch("http://localhost:1012/user", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    });
    console.log(userData,"aaa")
    const data = await response.json();
    return data;
  } catch (error) {
    console.log(error.Message);
  }
});

export const addUser = createAsyncThunk("user/addUser", async (userData, { rejectWithValue }) => {
  try {
    const response = await fetch("http://localhost:1012/user", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    });

    if (!response.ok) {
      throw new Error("Failed to add user"); // Throw error if response is not ok
    }

    const data = await response.json();
    return data;
  } catch (error) {
    return rejectWithValue(error.message); // Return error message
  }
});

export const loginuser = createAsyncThunk(
  "user/loginuser",
  async ({ values, navigate }, { rejectWithValue }) => {
    try {
      const response = await fetch("http://localhost:1012/user");
      const data = await response.json();

      const user = data.find(
        (u) => u.email === values.email && u.password === values.password
      );

      if (user) {
        navigate("/");
        return user;
      } else {
        return rejectWithValue("Invalid email or password");
      }
    } catch (error) {
      return rejectWithValue("Failed to fetch users");
    }
  }
);



export const sendOtp = createAsyncThunk(
  "user/sendOtp",
  async (email, { rejectWithValue }) => {
    try {
      const response = await axios.post("http://localhost:1012/verifyotp", { email });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const fetchUserByEmail = createAsyncThunk("user/fetchUserByEmail", async (email, { rejectWithValue }) => {
  try {
    const response = await fetch(`http://localhost:1012/user?email=${email}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error("User not found");
    }

    const data = await response.json();
    console.log("Fetched user data:", data); // Log the fetched user data
    return Array.isArray(data) ? data[0] : data; // Return the first user if it's an array
  } catch (error) {
    return rejectWithValue(error.message);
  }
});

export const changePassword = createAsyncThunk(
  "user/changePassword",
  async ({ email, newPassword }, { rejectWithValue }) => {
    try {
      const userResponse = await fetch(`http://localhost:1012/user?email=${email}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!userResponse.ok) {
        throw new Error("User not found");
      }

      const userData = await userResponse.json();
      const user = Array.isArray(userData) ? userData[0] : userData;

      if (!user || !user.id) {
        throw new Error("User data not found");
      }

      const response = await fetch(`http://localhost:1012/user/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...user, password: newPassword }),
      });

      if (!response.ok) {
        throw new Error("Failed to change password");
      }

      return { message: "Password changed successfully!" };
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const UserSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    logoutUser: (state) => {
      state.user = []; 
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getuser.fulfilled, (state, action) => {
        state.isloading = false;
        state.user = action.payload;
        state.error = null;
      })
      .addCase(addUser.fulfilled, (state, action) => {
        state.isloading = false;
        state.user.push(action.payload); 
        state.error = null;
      })
      .addCase(adduserdata.fulfilled, (state, action) => {
        state.isloading = false;
        state.user = state.user.concat(action.payload);
        state.error = null;
      })
      .addCase(loginuser.fulfilled, (state, action) => {
        console.log(action.payload);
        
        state.user = action.payload;
        state.error = null;
        state.isloading = false;
      })
      .addCase(loginuser.rejected, (state, action) => {
        state.error = action.payload;
        state.error = null;
        state.isloading = false;
      })
      .addCase(sendOtp.fulfilled, (state) => {
        state.isloading = false;
        state.error = null;
      })
      .addCase(sendOtp.rejected, (state, action) => {
        state.isloading = false; 
        state.error = action.payload; 
      });
  },
});


export const { logoutUser } = UserSlice.actions;
export default UserSlice.reducer;
