import { createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'user',
  initialState: {
    userData: null, // Initial state for user data
  },
  reducers: {
    adduserdata: (state, action) => {
      state.userData = action.payload; // Update the user data in the state
    },
    // You can add more reducers here as needed
  },
});

// Export the action to be used in the component
export const { adduserdata } = userSlice.actions;

// Export the reducer to be used in the store
export default userSlice.reducer;