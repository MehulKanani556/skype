import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  isloading: false,
  coupon: [],
  error: null,
};

export const getCoupon = createAsyncThunk(
  "coupon/getCoupon",
  async () => {
    try {
        const response = await fetch("http://localhost:1012/coupon");
        const data = await response.json();

        return data;
        // setCoupon(data); 
    } catch (error) {
        console.log(error.message);
    }
  }
);

export const addCoupon = createAsyncThunk(
  "coupon/addCoupon",
  async (v) => {
    try {
      const response = await fetch("http://localhost:1012/coupon", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;
    } catch (error) {}
  }
);

export const editCoupon = createAsyncThunk(
  "coupon/editCoupon",
  async (v) => {
    try {
      const response = await fetch(`http://localhost:1012/coupon/${v.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;
      // console.log(data);
  
      // setcatDate((prve) => prve.map((v) => v.id === data.id ? data : v))
    } catch (error) {
      console.error("Error edit coupon:", error);
    }
  }
);

export const deleteCoupon = createAsyncThunk(
  "coupon/deleteCoupon",
  async (v) => {
    try {
      const response = await fetch(`http://localhost:1012/coupon/${v.id}`, {
          method: 'DELETE',
          headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;

  } catch (error) {
      console.error('Error deleting coupon:', error);
  }
  }
);

const categorySlice = createSlice({
  name: "coupon",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getCoupon.fulfilled, (state, action) => {
        state.isloading = false;
        state.coupon = action.payload;
        state.error = null;
      })
      .addCase(addCoupon.fulfilled, (state, action) => {
        state.isloading = false;
        state.coupon = state.coupon.concat(action.payload);
        state.error = null;
      })
      .addCase(editCoupon.fulfilled, (state, action) => {
        state.isloading = false;
        state.coupon = state.coupon.map((v) =>
          v.id === action.payload.id ? action.payload : v
        );
        state.error = null;
      })
      .addCase(deleteCoupon.fulfilled, (state, action) => {
        state.isloading = false;
        state.coupon = state.coupon.filter((v) => v.id !== action.payload.id);
        state.error = null;
      });
  },
});

export default categorySlice.reducer;

