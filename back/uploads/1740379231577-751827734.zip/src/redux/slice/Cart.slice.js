import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isLoading: false,
  product: [],
  error: null
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      console.log(action.payload);

      const existingProductIndex = state.product.findIndex((v) => v.id === action.payload.id);
      console.log(existingProductIndex);

      if (existingProductIndex !== -1) {
        state.product[existingProductIndex].quantity = state.product[existingProductIndex].quantity + action.payload.count;
      } else { 
        const newProduct = { id: action.payload.id, quantity: action.payload.count };
        
        state.product.push(newProduct);
      }
    },
    
    IncrementQty: (state, action) => {
      const index = state.product.findIndex((v) => v.id === action.payload);

      state.product[index].quantity++;
    },

    DecrementQty: (state, action) => {
      const index = state.product.findIndex((v) => v.id === action.payload);

      if (state.product[index].quantity > 1) {
        state.product[index].quantity--;
      }
     
    },

    removeCart: (state, action) => {
        const fData = state.product.filter((v) => v.id !== action.payload);

        state.product = fData;
    }
    
  },
});

export const { addToCart, removeCart, IncrementQty, DecrementQty } = cartSlice.actions;

export default cartSlice.reducer;


