import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  isloading: false,
  product: [],
  error: null,
};

export const getProduct = createAsyncThunk("product/getProduct", async () => {
  try {
    const response = await fetch("http://localhost:1012/product");
    const data = await response.json();

    return data;
  } catch (error) {
    console.log(error.Message);
  }
});

export const addProduct = createAsyncThunk("product/addProduct", async (v) => {
  try {
    const response = await fetch("http://localhost:1012/product", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(v),
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.log(error.Message);
  }
});

export const editProduct = createAsyncThunk("product/editProduct", async (v) => {
  try {
    const response = await fetch(`http://localhost:1012/product/${v.id}`, {
      method: 'PUT',
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify(v)
  })
  const data = await response.json();
    return data;
  } catch (error) {
    console.log(error.Message);
  }
});


export const deleteProduct = createAsyncThunk("product/deleteProduct", async (v) => {
  try {
    const response = await fetch(`http://localhost:1012/product/${v.id}`, {
      method: 'DELETE',
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify(v)
  })
  const data = await response.json();
    return data;
  } catch (error) {
    console.log(error.Message);
  }
});

const categorySlice = createSlice({
  name: "product",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getProduct.fulfilled, (state, action) => {
        state.isloading = false;
        state.product = action.payload;
        state.error = null;
      })
      .addCase(addProduct.fulfilled, (state, action) => {
        state.isloading = false;
        state.product = state.product.concat(action.payload);
        state.error = null;
      })
      .addCase(editProduct.fulfilled, (state, action) => {
        state.isloading = false;
        state.product = state.product.map((v) =>
          v.id === action.payload.id ? action.payload : v
        );
        state.error = null;
      })
      .addCase(deleteProduct.fulfilled, (state, action) => {
        state.isloading = false;
        state.product = state.product.filter((v) => v.id !== action.payload.id);
        state.error = null;
      });
  },
});

export default categorySlice.reducer;
