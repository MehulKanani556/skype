import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  isloading: false,
  category: [],
  error: null,
};

export const getCategory = createAsyncThunk(
  "category/getCategory",
  async () => {
    try {
      const response = await fetch("http://localhost:1012/category");
      const data = await response.json();

      return data;
    } catch (error) {
      console.log(error.Message);
    }
  }
);

export const addCategorydata = createAsyncThunk(
  "category/addCategorydata",
  async (v) => {
    try {
      const response = await fetch("http://localhost:1012/category", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;
    } catch (error) {}
  }
);

export const editCategorydata = createAsyncThunk(
  "category/editCategorydata",
  async (v) => {
    try {
      const response = await fetch(`http://localhost:1012/category/${v.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;
      // console.log(data);
  
      // setcatDate((prve) => prve.map((v) => v.id === data.id ? data : v))
    } catch (error) {
      console.error("Error edit category:", error);
    }
  }
);

export const deleteCategorydata = createAsyncThunk(
  "category/deleteCategorydata",
  async (v) => {
    try {
      const response = await fetch(`http://localhost:1012/category/${v.id}`, {
          method: 'DELETE',
          headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(v),
      });
      const data = await response.json();
      return data;

  } catch (error) {
      console.error('Error deleting category:', error);
  }
  }
);



const categorySlice = createSlice({
  name: "category",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getCategory.fulfilled, (state, action) => {
        state.isloading = false;
        state.category = action.payload;
        state.error = null;
      })
      .addCase(addCategorydata.fulfilled, (state, action) => {
        state.isloading = false;
        state.category = state.category.concat(action.payload);
        state.error = null;
      })
      .addCase(editCategorydata.fulfilled, (state, action) => {
        state.isloading = false;
        state.category = state.category.map((v) =>
          v.id === action.payload.id ? action.payload : v
        );
        state.error = null;
      })
      .addCase(deleteCategorydata.fulfilled, (state, action) => {
        state.isloading = false;
        state.category = state.category.filter((v) => v.id !== action.payload.id);
        state.error = null;
      });
  },
});

export default categorySlice.reducer;
