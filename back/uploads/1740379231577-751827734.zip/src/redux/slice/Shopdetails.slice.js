import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  isloading: false,
  reviews: [],
  error: null,
};

export const addReview = createAsyncThunk("reviews/addReview", async (Data) => {
  try {
    const reviewData = {
      ...Data,
      userId: "1111",
      status: "pending",
    };

    const response = await fetch("http://localhost:1012/reviews", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(reviewData),
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error adding review:", error);
    return error.message;
  }
});

export const getReviews = createAsyncThunk("reviews/getReviews", async () => {
  try {
    const response = await fetch("http://localhost:1012/reviews", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching reviews:", error);
    return error.message;
  }
});

export const updateStatus = createAsyncThunk(
  "reviews/updateStatus",
  async (data) => {
    try {
      const response = await fetch("http://localhost:1012/reviews/" + data.id, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          status: data.status === "active" ? "pending" : "active",
        }),
      });

      const dataR = await response.json();

      return dataR;
    } catch (error) {
      console.log("error in update status: ", error);
    }
  }
);

export const deleteReview = createAsyncThunk(
  "reviews/deleteReview",
  async (id) => {
    try {
      const response = await fetch(`http://localhost:1012/reviews/${id}`, {
        method: "DELETE"
      });
      if (!response.ok) {
        throw new Error("Failed to delete the review");
      }
      return id;
    } catch (error) {
      console.error("Error deleting review:", error);
      throw error;
    }
  }
);

export const updateReview = createAsyncThunk(
  "reviews/updateReview",
  async (updatedReview) => {
    try {
      const response = await fetch(
        `http://localhost:1012/reviews/${updatedReview.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedReview),
        }
      );
      return await response.json();
    } catch (error) {
      console.error("Error updating review:", error);
      throw error;
    }
  }
);

const ReviewSlice = createSlice({
  name: "reviews",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(addReview.fulfilled, (state, action) => {
        console.log(action);

        state.isloading = false;
        state.reviews = state.reviews.concat(action.payload);
        state.error = null;
      })
      .addCase(getReviews.fulfilled, (state, action) => {
        console.log(action);

        state.isloading = false;
        state.reviews = action.payload;
        state.error = null;
      })
      .addCase(updateStatus.fulfilled, (state, action) => {
        console.log(action);
        state.isloading = false;
        state.reviews = state.reviews.map((v) => {
          if (v.id === action.payload.id) {
            return action.payload;
          } else {
            return v;
          }
        });
        state.error = null;
      })
      .addCase(deleteReview.fulfilled, (state, action) => {
        state.reviews = state.reviews.filter((review) => review.id !== action.payload);
        state.error = null;
      })
      .addCase(updateReview.fulfilled, (state, action) => {
        const index = state.reviews.findIndex(
          (review) => review.id === action.payload.id
        );
        state.reviews[index] = action.payload;
        state.error = null;
        console.log(index);        
      });
  },
});

export default ReviewSlice.reducer;
