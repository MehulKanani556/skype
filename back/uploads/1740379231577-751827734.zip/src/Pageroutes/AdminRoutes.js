import React from "react";
import Sidebar from "../Admin/Component/Sidebar";
import { Route, Routes } from "react-router-dom";
import Category from "../Admin/Container/Category";
import Subcategory from "../Admin/Container/Subcategory";
import Products from "../Admin/Container/Products";
import Coupon from "../Admin/Container/Coupon";
import Review from "../Admin/Container/Review";
import Order from "../Admin/Container/Order";
import View from "../Admin/Container/View";

function AdminRoutes(props) {
  return (
    <Sidebar>
      <Routes>
        <Route path="/category" element={<Category />} />
        <Route path="/subcategory" element={<Subcategory />} />
        <Route path="/products" element={<Products />} />
        <Route path="/coupon" element={ <Coupon />  }/>
        <Route path="/review" element={<Review/> } />
        <Route path="/order" element={<Order/> } />
        <Route path="/view/:id" element={<View />} /> 
      </Routes>
    </Sidebar>
  );
}

export default AdminRoutes;




