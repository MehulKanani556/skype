import React, { useContext } from "react";
import Header from "../Component/Header/Header";
import Footer from "../Component/Footer/Footer";
import { Route, Routes } from "react-router-dom";
import Shope from "../Container/Shope";
import Shopedetails from "../Container/Shopedetails";
import Cart from "../Container/Cart";
import Checkout from "../Container/Checkout";
import Tastimonial from "../Container/Tastimonial";
import Contactus from "../Container/Contactus";
import PrivateRoutes from "./PrivateRoutes";
import Homef from "../Container/Homef";
import Signin from "../Container/Signin";
import Tryform from "../Container/Tryform";
import { Themecontex } from "../Context/ThemeContext";
import Order from "../Container/Order";
import OrderDetail from "../Container/OrderDetail";


function UserRoutes(props) {
  const t = useContext(Themecontex);

  return (
    <div className={`${t.theme}`}>
      <Header />
      <Routes>
        <Route path="/" element={<Homef />} />
        <Route path="/shope" element={<Shope />} />
        <Route path="/shopedetails/:item_id" element={<Shopedetails />} />
        <Route element={<PrivateRoutes />}>
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/Order" element={<Order />} />
          <Route path="/orderdetails/:orderId" element={<OrderDetail />} />
        </Route>
        <Route path="/tastimonial" element={<Tastimonial />} />
        <Route path="/contactus" element={<Contactus />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/tryform" element={<Tryform />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default UserRoutes;
