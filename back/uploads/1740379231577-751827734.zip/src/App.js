import { Route, Routes } from "react-router-dom";
import "./App.css";
import AdminRoutes from "./Pageroutes/AdminRoutes";
import UserRoutes from "./Pageroutes/UserRoutes";
import PrivateRoutes from "./Pageroutes/PrivateRoutes";
import { Provider } from "react-redux";
import Counter from "./Admin/Counter/Counter";
import Getcategory from "./Getcategory";
import Welcomefile from "./Context/Welcomefile";
import { Themeprovider } from "./Context/ThemeContext";
import { configureStore } from "./redux/Store";
import { PersistGate } from 'redux-persist/integration/react'

function App() {
  const { store, persistor } = configureStore();

  return (
    <Themeprovider value='dark'>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <Routes>
            <Route path="/*" element={<UserRoutes />} />
            <Route path="/get" element={<Getcategory />} />

            <Route element={<PrivateRoutes />}>
              <Route path="/admin/*" element={<AdminRoutes />} />
              <Route path="/con" element={<Counter />} />
            </Route>
          </Routes>
        </PersistGate>
      </Provider>
    </Themeprovider>
  );
}

export default App;


