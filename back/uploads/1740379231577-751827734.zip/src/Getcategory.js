import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getCategory } from './redux/action/Category.action';

function Getcategory(props) {
    const dispatch =  useDispatch();

    const state = useSelector(state => state);
    console.log(state);
    

    const fetchdata = () => {
        dispatch(getCategory());
    }
    return (
        <div>
            <button onClick={() => fetchdata()}>fetch category</button>
            {/* {state.Getcategory} */}
        </div>
    );
}

export default Getcategory;

