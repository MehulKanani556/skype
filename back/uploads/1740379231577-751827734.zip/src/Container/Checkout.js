import React, { useState } from "react";
import { Card, Col, Container, Form, NavLink, Row } from "react-bootstrap";
import { array, mixed, number, object, string, ref, boolean } from "yup";
import { useFormik } from "formik";
import { Link, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addcheck } from "../redux/slice/Checkout.slice";
import { colors } from "@mui/material";

function Checkout(props) {
    let location = useLocation();

    const [cartData, setcartData] = useState(location.state);
    const [showModal, setShowModal] = useState(false); // State to control modal visibility
    // console.log(cartData.cartData)
    // const checkout = useSelector((state) => state.checkout);
    // console.log(checkout.checkout);
    const dispatch = useDispatch();

    const checkout = useSelector((state) => state.checkout);
    console.log(checkout);

    const initialValues = {
        name: "",
        lastname: "",
        country: "",
        address: "",
        city: "",
        pincode: "",
        mobileNumber: "",
        email: "",
        Delivery: false
    };

    // Validation
    const validationSchema = object({
        name: string()
            .matches(/^[a-zA-Z\s]+$/, "Only alphabets are allowed")
            .required("First Name is required"),
        lastname: string()
            .matches(/^[a-zA-Z\s]+$/, "Only alphabets are allowed")
            .required("Last Name is required"),
        country: string().required("Country is required"),

        address: string().test("address", "Max 5 words allowed", function (val) {
            let arr = val?.trim()?.split(" ");
            return arr?.length <= 5;
        }),
        city: string().required("Country is required"),
        pincode: string()
            .matches(
                /^[1-9][0-9]{5}$/,
                "Pincode must be 6 digits and cannot start with 0"
            )
            .required("Pincode is required"),
        mobileNumber: string()
            .matches(/^[0-9]{10}$/, "Mobile number must be exactly 10 digits")
            .required("Mobile number is required"),
        email: string().email("Invalid email format").required("Email is required"),
        Delivery: boolean().oneOf([true], "Please select payment method"),
    });

    const eform = useFormik({
        initialValues,
        validationSchema,
        onSubmit: (values, { resetForm }) => {
            handleAdd(values);
            console.log(values);
            resetForm(); // Reset the form after submission
        },
    });

    const { handleBlur, handleChange, handleSubmit, errors, touched, values } =
        eform;

    console.log(errors);

    const totalAmount = cartData.cartData.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    );
    const handleAdd = async (values) => {
        console.log(values);

        // Validate the form
        const isValid = await eform.validateForm();

        // Check if the form is valid
        if (Object.keys(isValid).length === 0) {
            const orderData = {
                uid: "111",
                Status:"Pending",
                cart: cartData.cartData.map((item) => ({
                    pid: item.id,
                    qty: item.quantity,
                    amt: item.price * item.quantity,
                })),
                billing_details: {
                    ...values,
                },
                total_amt: totalAmount,
            };
            dispatch(addcheck(orderData));
            setShowModal(true); // Show the modal if the form is valid
        } else {
            console.log("Form is invalid");
            setShowModal(false); // Ensure modal is not shown if form is invalid
        }
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false); // Close the modal
    };

    return (
        <div>
            {/* Single Page Header start */}
            <div className="container-fluid page-header py-5">
                <h1 className="text-center text-white display-6">Checkout</h1>
                <ol className="breadcrumb justify-content-center mb-0">
                    <li className="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li className="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li className="breadcrumb-item active text-white">Checkout</li>
                </ol>
            </div>
            {/* Single Page Header End */}

            {/* Checkout Page Start */}
            <div className="container-fluid py-5">
                <div className="container py-5">
                    <h1 className="mb-4">Billing details</h1>
                    <Form action="" onSubmit={handleSubmit}>
                        <div className="row g-5">
                            <div className="col-md-12 col-lg-6 col-xl-7">
                                <div className="row">
                                    <div className="col-md-12 col-lg-6">
                                        <div className="form-item w-100">
                                            {/* first Name */}
                                            <div className="mb-0">
                                                <label>
                                                    First Name<sup>*</sup>
                                                </label>
                                                <Form.Control
                                                    type="text"
                                                    name="name"
                                                    onChange={handleChange}
                                                    onBlur={handleBlur}
                                                    value={values.name}
                                                />
                                                {touched.name && errors.name ? (
                                                    <span className="text-danger">{errors.name}</span>
                                                ) : null}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12 col-lg-6 ">
                                        <div className="form-item w-100 ">
                                            {/*last Name */}
                                            <div className="mb-0">
                                                <label>
                                                    Last Name<sup>*</sup>
                                                </label>
                                                <Form.Control
                                                    type="text"
                                                    name="lastname"
                                                    onChange={handleChange}
                                                    onBlur={handleBlur}
                                                    value={values.lastname}
                                                />
                                                {touched.lastname && errors.lastname ? (
                                                    <span className="text-danger">{errors.lastname}</span>
                                                ) : null}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* Country */}
                                    <div className="mb-0">
                                        <label className="form-label my-3">
                                            Country<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            as="select"
                                            name="country"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.country}
                                        >
                                            <option value="">Select...</option>
                                            <option value="USA">USA</option>
                                            <option value="India">India</option>
                                            <option value="UK">UK</option>
                                        </Form.Control>
                                        {touched.country && errors.country ? (
                                            <span className="text-danger">{errors.country}</span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* Address */}
                                    <div className="mb-0">
                                        <label className="form-label my-3">
                                            Address<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            as="textarea"
                                            type="text"
                                            name="address"
                                            placeholder="House Number Street Name"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.address}
                                        />
                                        {touched.address && errors.address ? (
                                            <span className="text-danger">{errors.address}</span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* <label className="form-label my-3">Town/City<sup>*</sup></label>
                                    <input type="text" className="form-control" /> */}
                                    {/* Country */}
                                    <div className="mb-0">
                                        <label className="form-label my-3">
                                            Town/City<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            as="select"
                                            name="city"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.city}
                                        >
                                            <option value="">Select...</option>
                                            <option value="USA">Los Angeles</option>
                                            <option value="India">Bangluru</option>
                                            <option value="UK">Lobdon</option>
                                        </Form.Control>
                                        {touched.city && errors.city ? (
                                            <span className="text-danger">{errors.city}</span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* <label className="form-label my-3">Postcode/Zip<sup>*</sup></label>
                                    <input type="text" className="form-control" /> */}
                                    {/*last Name */}
                                    <div className="mb-0">
                                        <label className="form-label my-3">
                                            Postcode/Zip<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            type="text"
                                            name="pincode"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.pincode}
                                        />
                                        {touched.pincode && errors.pincode ? (
                                            <span className="text-danger">{errors.pincode}</span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* <label className="form-label my-3">Mobile<sup>*</sup></label>
                                    <input type="tel" className="form-control" /> */}
                                    {/*last Name */}
                                    <div className="mb-0">
                                        <label className="form-label my-3">
                                            Mobile<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            type="text"
                                            name="mobileNumber"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.mobileNumber}
                                        />
                                        {touched.mobileNumber && errors.mobileNumber ? (
                                            <span className="text-danger">{errors.mobileNumber}</span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="form-item">
                                    {/* <label className="form-label my-3">Email Address<sup>*</sup></label>
                                    <input type="email" className="form-control" /> */}
                                    {/* Email */}
                                    <div className="mb-4">
                                        <label className="form-label my-3">
                                            Email Address<sup>*</sup>
                                        </label>
                                        <Form.Control
                                            type="email"
                                            name="email"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.email}
                                        />
                                        {touched.email && errors.email ? (
                                            <span className="text-danger">{errors.email}</span>
                                        ) : null}
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12 col-lg-6 col-xl-5">
                                <div className="table-responsive">
                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Products</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Price</th>
                                                <th scope="col">Quantity</th>
                                                <th scope="col">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {cartData.cartData.map((item, index) => (
                                                // console.log(JSON.stringify(item),"itm")

                                                <tr key={index}>
                                                    <th scope="row">
                                                        <div className="d-flex align-items-center mt-2">
                                                            <img
                                                                src="img/vegetable-item-2.jpg"
                                                                className="img-fluid rounded-circle"
                                                                style={{ width: 90, height: 90 }}
                                                                alt={item.name}
                                                            />
                                                        </div>
                                                    </th>
                                                    <td className="py-5">{item.productName}</td>
                                                    <td className="py-5">${item.price}</td>
                                                    <td className="py-5">{item.quantity}</td>
                                                    <td className="py-5">
                                                        ${item.price * item.quantity}
                                                    </td>
                                                </tr>
                                            ))}
                                            <tr>
                                                <th scope="row"></th>
                                                <td className="py-5">
                                                    <p className="mb-0 text-dark text-uppercase py-3">
                                                        TOTAL
                                                    </p>
                                                </td>
                                                <td className="py-5" />
                                                <td className="py-5" />
                                                <td className="py-5">
                                                    <div className="py-3 border-bottom border-top">
                                                        <p className="mb-0 text-dark pay_total">
                                                            ${totalAmount}.00
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div className="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                    <div className="col-12">
                                        <div className="form-check text-start my-3">
                                            <input
                                                type="checkbox"
                                                className="form-check-input bg-primary border-0"
                                                id="Transfer-1"
                                                name="Transfer"
                                                defaultValue="Transfer"
                                                disabled
                                            />
                                            <label className="form-check-label" htmlFor="Transfer-1">
                                                Direct Bank Transfer
                                            </label>
                                        </div>
                                        <p className="text-start text-dark">
                                            Make your payment directly into our bank account. Please
                                            use your Order ID as the payment reference. Your order
                                            will not be shipped until the funds have cleared in our
                                            account.
                                        </p>
                                    </div>
                                </div>
                                <div className="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                    <div className="col-12">
                                        <div className="form-check text-start my-3">
                                            <input
                                                type="checkbox"
                                                className="form-check-input bg-primary border-0"
                                                id="Payments-1"
                                                name="Payments"
                                                defaultValue="Payments"
                                                disabled
                                            />
                                            <label className="form-check-label" htmlFor="Payments-1">
                                                Check Payments
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div className="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                    <div className="col-12">
                                        <div className="form-check text-start my-3">
                                            <input
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                value={values.Delivery}
                                                type="checkbox"
                                                className="form-check-input bg-primary border-0"
                                                id="Delivery-1"
                                                name="Delivery"
                                                defaultValue="Delivery"
                                            />
                                            <label className="form-check-label" htmlFor="Delivery-1">
                                                Cash On Delivery
                                            </label>
                                            {touched.Delivery && errors.Delivery ? (
                                                <span className="text-danger">{errors.Delivery}</span>
                                            ) : null}
                                        </div>
                                    </div>
                                </div>
                                <div className="row g-4 text-center align-items-center justify-content-center border-bottom py-3">
                                    <div className="col-12">
                                        <div className="form-check text-start my-3">
                                            <input
                                                type="checkbox"
                                                className="form-check-input bg-primary border-0"
                                                id="Paypal-1"
                                                name="Paypal"
                                                defaultValue="Paypal"
                                                disabled
                                            />
                                            <label className="form-check-label" htmlFor="Paypal-1">
                                                Paypal
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div className="row g-4 text-center align-items-center justify-content-center pt-4">
                                    <button
                                        type="submit"
                                        className="btn border-secondary py-3 px-4 text-uppercase w-100 text-primary"
                                        data-bs-toggle="modal"
                                        data-bs-target="#exampleModal"
                                    >
                                        Place Order
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div
                            class="modal fade"
                            id="exampleModal"
                            tabindex="-1"
                            aria-labelledby="exampleModalLabel"
                            aria-hidden="true"
                        >
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button
                                            type="button"
                                            class="btn-close"
                                            data-bs-dismiss="modal"
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                    <div class="modal-body">
                                        <h5
                                            class="modal-title text-center"
                                            id="exampleModalLabel"
                                            style={{ color: "gray" }}
                                        >
                                            Thank you for your order
                                        </h5>
                                        <div className="w-100" style={{ color: "gray" }}></div>
                                    </div>
                                    <div class="modal-footer">
                                        <button
                                            type="button"
                                            class="btn btn-secondary"
                                            data-bs-dismiss="modal"
                                        >
                                            Close
                                        </button>
                                        <NavLink to={"/Order"} class="btn btn-primary">
                                            Save changes
                                        </NavLink>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Form>
                </div>
            </div>

            {/* Checkout Page End */}
        </div>
    );
}

export default Checkout;
