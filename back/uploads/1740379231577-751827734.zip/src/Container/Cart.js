import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  DecrementQty,
  IncrementQty,
  removeCart,
} from "../redux/slice/Cart.slice";
import { colors, TextField } from "@mui/material";
import { useFormik } from "formik";
import { object, string } from "yup";
import { getCoupon } from "../redux/slice/Coupon.slice";
import { Link, NavLink } from "react-router-dom";

function Cart() {
  const dispatch = useDispatch();

  const couponData = useSelector((state) => state.coupon.coupon);
  console.log(couponData);

  const [couponMessage, setCouponMessage] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);



  useEffect(() => {
    dispatch(getCoupon());
  }, [dispatch]);

  const cart = useSelector((state) => state.cart);
  const product = useSelector((state) => state.product);
  console.log(cart.product);

  console.log(product.product);

  const cartData = cart.product.map((vp) => {
    const cartP = product.product.find((vc) => vc.id === vp.id);
    if (cartP) {
      return { ...vp, ...cartP };
    }
  });
  console.log(cartData);

  const handleRemove = (id) => {
    dispatch(removeCart(id));
  };

  const handleIncrement = (id) => {
    dispatch(IncrementQty(id));
  };

  const handleDecrement = (id) => {
    dispatch(DecrementQty(id));
  };

  const handleSubmit = (values) => {
    console.log("Coupon Code entered:", values.couponCode);

    // Check if the entered coupon code matches any in the couponData
    const matchedCoupon = couponData.find(
      (coupon) => coupon.couponCode === values.couponCode
    );

    if (matchedCoupon) {
      console.log("Successfully applied your coupon!");
      setCouponMessage("Successfully applied your coupon!");
      setAppliedCoupon(matchedCoupon);
    } else {
      console.log("Coupon code is invalid.");
      setCouponMessage("Coupon code is invalid.");
    }


    // Additional logic for coupon validation can go here
  };

  // yup validation
  let couponSchema = object({
    couponCode: string().required("Enter coupon code!"),
  });

  const formik = useFormik({
    initialValues: {
      couponCode: "",
    },
    validationSchema: couponSchema,
    onSubmit: (values, { resetForm }) => {
      console.log("submit value:", values);
      handleSubmit(values);
      resetForm();
    },
  });

  const {
    handleBlur,
    handleChange,
    errors,
    values,
    touched,
    setValues,
    resetForm,
  } = formik;

  return (
    <div>
      {/* Single Page Header start */}
      <div className="container-fluid page-header py-5">
        <h1 className="text-center text-white display-6">Cart</h1>
        <ol className="breadcrumb justify-content-center mb-0">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item active text-white">Cart</li>
        </ol>
      </div>
      {/* Single Page Header End */}

      {/* Cart Page Start */}
      <div className="container-fluid py-5">
        <div className="container py-5">
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  {/* <th scope="col">Products</th> */}
                  <th scope="col">Name</th>
                  <th scope="col">Price</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Total</th>
                  <th scope="col">Handle</th>
                </tr>
              </thead>
              <tbody>
                {cartData.map((v, index) => (
                  // console.log("aaa", v, index)
                  <tr key={index}>
                    <td>{v.productName}</td>
                    <td>{v.price}</td>
                    <td>
                      <div
                        className="input-group quantity"
                        style={{ width: 100 }}
                      >
                        <div className="input-group-btn">
                          <button
                            disabled={v.quantity === 1 ? true : false}
                            className="btn btn-sm btn-minus rounded-circle border"
                            onClick={() => handleDecrement(v.id)}
                          >
                            <i className="fa fa-minus" />
                          </button>
                        </div>
                        <input
                          type="text"
                          className="form-control form-control-sm text-center border-0 bg-transparent"
                          value={v.quantity}
                          readOnly
                        />
                        <div className="input-group-btn">
                          <button
                            className="btn btn-sm btn-plus rounded-circle border "
                            onClick={() => handleIncrement(v.id)}
                          >
                            <i className="fa fa-plus" />
                          </button>
                        </div>
                      </div>
                    </td>
                    <td>{v.price * v.quantity}</td>

                    <td>
                      <button
                        className="btn btn-md rounded-circle bg-light border"
                        onClick={() => handleRemove(v.id)}
                      >
                        <i className="fa fa-times text-danger" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-5">
            <form onSubmit={formik.handleSubmit}>
              <TextField
                id="couponCode"
                name="couponCode"
                type="text"
                className="border-0 border-bottom rounded me-5 py-3 mb-4"
                placeholder="Coupon Code"
                value={values.couponCode}
                onChange={handleChange}
                onBlur={handleBlur}
                error={Boolean(errors.couponCode && touched.couponCode)}
                helperText={
                  errors.couponCode && touched.couponCode
                    ? errors.couponCode
                    : ""
                }
              />
              <button
                name="apply"
                id="apply"
                type="submit"
                className="btn border-secondary rounded-pill px-4 py-3 text-primary"
              >
                Apply Coupon
              </button>
            </form>
            <div>
              {couponMessage && <p>{couponMessage}</p>}
            </div>

          </div>
          <div className="row g-4 justify-content-end">
            <div className="col-8" />
            <div className="col-sm-8 col-md-7 col-lg-6 col-xl-4">
              <div className="bg-light rounded">
                <div className="p-4">
                  <h1 className="display-6 mb-4">
                    Cart <span className="fw-normal">Total</span>
                  </h1>
                  <div className="d-flex justify-content-between mb-4">
                    <h5 className="mb-0 me-4">Subtotal:</h5>
                    <p className="mb-0">
                      {/* Calculate and display the total of all items in the cart */}
                      $
                      {cartData.reduce(
                        (total, item) => total + item.price * item.quantity,
                        0
                      )}
                      {/* console.log("t :", total , "i :", item) */}
                    </p>
                  </div>
                  <div className="d-flex justify-content-between mb-4">
                    <h5 className="mb-0 me-4">Discount:</h5>
                    <p className="mb-0">
                      {appliedCoupon?.discountPercentage || 0}%
                    </p>
                  </div>
                  <div className="d-flex justify-content-between">
                    <h5 className="mb-0 me-4">Shipping</h5>
                    <div className>
                      <p className="mb-0">Flat rate: $3.00</p>
                    </div>
                  </div>
                  <p className="mb-0 text-end">Shipping to Ukraine.</p>
                </div>
                <div className="py-4 mb-4 border-top border-bottom d-flex justify-content-between">
                  <h5 className="mb-0 ps-4 me-4">Total</h5>
                  <p className="mb-0 pe-4">
                    {/* Calculate and display total */}
                    ${(() => {
                      const subtotal = cartData.reduce(
                        (total, item) => total + item.price * item.quantity,
                        0
                      );
                      const discountPercentage = appliedCoupon?.discountPercentage || 0;
                      const discountAmount = (subtotal * discountPercentage) / 100;
                      return subtotal + 3 - discountAmount;
                    })()}
                  </p>
                </div>
                <NavLink
                  to={{ pathname: `/checkout` }}
                  state={{cartData}}
                >
                  <button
                    className="btn border-secondary rounded-pill px-4 py-3 text-primary text-uppercase mb-4 ms-4"
                    type="button"
                  >
                    Proceed Checkout
                  </button>
                </NavLink>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Cart Page End */}
    </div>
  );
}

export default Cart;

// [
//   {
//     id: 'sdcs',
//     name: 'dff',
//     email: 'eee@gmail.com',
//     comment: 'df',
//     rating: 3,
//     pid: '1829',
//     uid: '',
//     status: 'approve'
//   }
// ]
