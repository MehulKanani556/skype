import React, { useState, useRef } from "react";
import { Row, Col, Card, Form, Button, Image, Container } from "react-bootstrap";
import { object, string, ref } from "yup"; // Import yup schema validation
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import emailjs from '@emailjs/browser';
import { addUser, loginuser, changePassword } from "../redux/slice/User.slice";
import { useNavigate } from "react-router-dom";

function Signin() {
  // State management
  const [type, setType] = useState("login");
  const [showOtpForm, setShowOtpForm] = useState(false);
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const form = useRef();

  let authSchema = {}, initialValues = {};

  if (type === "login") {
    authSchema = object({
      email: string().email().required(),
      password: string().required(),
    });
    initialValues = { email: "", password: "" };
  } else if (type === "signup") {
    authSchema = object({
      name: string().required(),
      email: string().email().required(),
      password: string().required(),
    });
    initialValues = { name: "", email: "", password: "" };
  } else if (type === "forgot") {
    authSchema = object({
      email: string().email().required(),
    });
    initialValues = { email: "" };
  } else if (type === "resetPassword") {
    authSchema = object({
      newPassword: string().required().min(6, "Password must be at least 6 characters"),
      confirmPassword: string()
        .oneOf([ref('newPassword'), null], 'Passwords must match')
        .required(),
    });
    initialValues = { newPassword: "", confirmPassword: "" };
  }

  const generateOTP = () => {
    const otp = Math.floor(Math.random() * 9000 + 1000).toString();
    setGeneratedOtp(otp);
    return otp;
  };

  const sendOtpEmail = async (userEmail, userName, otpCode) => {
    try {
      const templateParams = {
        user_email: userEmail,
        user_name: userName,
        otp: otpCode,
        subject: "Your OTP Verification Code",
        message: `Your OTP verification code is: ${otpCode}`,
      };

      const result = await emailjs.send(
        'service_w8detyb',
        'template_3pniioi',
        templateParams,
        'ttCTZFAU-GNSs14c5'
      );

      console.log('Email sent successfully:', result);
      return true;
    } catch (error) {
      console.error('Failed to send OTP email:', error);
      return false;
    }
  };

  const handleOtpChange = (index, value) => {
    if (!/^\d{0,1}$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value !== "" && index < 3) {
      const nextInput = document.querySelector(`input[name=otp-${index + 1}]`);
      if (nextInput) nextInput.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === 'Backspace' && index > 0 && otp[index] === '') {
      const prevInput = document.querySelector(`input[name=otp-${index - 1}]`);
      if (prevInput) prevInput.focus();
    }
  };


  const handleVerifyOtp = async (type) => {
    console.log("type", type);

    const enteredOtp = otp.join("");

    if (enteredOtp === generatedOtp) {

      if (type === "rverify") {
        try {
          const userData = {
            name: formik.values.name,
            email: formik.values.email,
            password: formik.values.password
          };


          const response = await fetch('http://localhost:1012/user', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData),
          });

          if (response.ok) {
            alert("Registration successful!");
            setType("login");
            formik.resetForm();
            // setShowOtpForm(false);
            setOtp(["", "", "", ""]);
          } else {
            throw new Error('Registration failed');
          }
        } catch (error) {
          console.error("Registration failed:", error);
          alert("Registration failed. Please try again.");
        }
      } else {
        setType("resetPassword");
      }

    } else {
      alert("Invalid OTP. Please try again.");
    }
  };
  // const handleVerifyOtp = async (type) => {
  //   console.log("type", type);

  //   const enteredOtp = otp.join("");

  //   if (enteredOtp === generatedOtp) {
  //     if (type === "rverify") {
  //       try {
  //         const userData = {
  //           name: formik.values.name,
  //           email: formik.values.email,
  //           password: formik.values.password
  //         };

  //         // Dispatch the user data to the Redux store
  //         const resultAction = await dispatch(addUser(userData)); // Dispatch the addUser action

  //         if (addUser.fulfilled.match(resultAction)) {
  //           alert("Registration successful!");
  //           setType("login");
  //           formik.resetForm();
  //           setOtp(["", "", "", ""]);
  //         } else {
  //           alert("Registration failed. Please try again."); // Handle failure
  //         }
  //       } catch (error) {
  //         console.error("Registration failed:", error);
  //         alert("Registration failed. Please try again.");
  //       }
  //     } else {
  //       setType("resetPassword");
  //     }
  //   } else {
  //     alert("Invalid OTP. Please try again.");
  //   }
  // };
  const handleResendOtp = async () => {
    const otpCode = generateOTP();
    const emailSent = await sendOtpEmail(
      formik.values.email,
      formik.values.name,
      otpCode
    );

    if (emailSent) {
      setType("rverify");
      alert("New OTP has been sent to your ${values.email}");
    } else {
      alert("Failed to resend OTP. Please try again.");
    }
  };

  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match. Please try again.");
      return;
    }

    try {
      const storedEmail = localStorage.getItem("forgotPasswordEmail");
      if (!storedEmail) {
        alert("Email not found. Please try the forgot password process again.");
        return;
      }

      const resultAction = await dispatch(changePassword({ email: storedEmail, newPassword }));
      if (changePassword.fulfilled.match(resultAction)) {
        alert(resultAction.payload.message);
        localStorage.removeItem("forgotPasswordEmail");
        setType("login");
        setNewPassword("");
        setConfirmPassword("");
      } else {
        alert("Failed to change password. Please try again.");
      }
    } catch (error) {
      console.error("Error occurred while changing password:", error);
      alert("An unexpected error occurred. Please try again.");
    }
  };


  const formik = useFormik({
    initialValues,
    validationSchema: authSchema,
    enableReinitialize: true,
    onSubmit: async (values, { resetForm }) => {
      if (type === "signup") {
        try {
          const otpCode = generateOTP();
          const emailSent = await sendOtpEmail(
            values.email,
            values.name,
            otpCode
          );

          if (emailSent) {
            setType("rverify");
            alert(`OTP has been sent to ${values.email}`);
          } else {
            alert("Failed to send OTP. Please try again.");
          }
        } catch (error) {
          console.error("Signup error:", error);
          alert("Error during signup process");
        }
      } else if (type === "login") {
        try {
          const result = dispatch(loginuser({ values, navigate }));
          if (result.meta.requestStatus === "fulfilled") {
            console.log("Login successful!");
            resetForm();
          }
        } catch (error) {
          console.log("Login failed:", error);
        }
      } else if (type === "forgot") {
        // Store email in localStorage
        localStorage.setItem("forgotPasswordEmail", values.email);
        // Log the email to console
        console.log("Forgot password email:", values.email);

        const otpCode = generateOTP();
        const emailSent = await sendOtpEmail(values.email, '', otpCode);
        if (emailSent) {
          setType("fverify");
          alert(`OTP has been sent to ${values.email}`);
        } else {
          alert("Failed to send OTP. Please try again.");
        }
      }
    }
  });

  return (
    <Container fluid className="mt-5">
      <Card className="text-black" style={{ borderRadius: "25px", marginTop: "200px" }}>
        <Card.Body>
          <Row className="align-items-center">
            <Col md={10} lg={6} className="order-2 order-lg-1 d-flex flex-column align-items-center">
              {(type === "fverify" || type === "rverify") ? (
                <div className="w-75">
                  <h2 className="text-center mb-4">Enter OTP</h2>
                  <p className="text-center mb-4">
                    We've sent a 4-digit OTP to {formik.values.email}
                  </p>
                  <div className="d-flex justify-content-between mb-4">
                    {otp.map((digit, index) => (
                      <Form.Control
                        key={index}
                        name={`otp-${index}`}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(index, e)}
                        className="mx-2 text-center"
                        style={{
                          width: "50px",
                          height: "50px",
                          fontSize: "24px",
                          borderRadius: "8px"
                        }}
                        autoFocus={index === 0}
                      />
                    ))}
                  </div>
                  <Button
                    className="w-100 mb-3"
                    onClick={() => handleVerifyOtp(type)}
                    disabled={otp.join("").length !== 4}
                  >
                    Verify OTP
                  </Button>
                  <p className="text-center">
                    Didn't receive OTP?{" "}
                    <Button
                      variant="link"
                      className="p-0"
                      onClick={handleResendOtp}
                    >
                      Resend
                    </Button>
                  </p>
                </div>
              ) : type === "resetPassword" ? (
                <div className="w-75">
                  <h2 className="text-center mb-4">Reset Password</h2>
                  <Form.Group className="mb-4">
                    <Form.Control
                      type="password"
                      placeholder="New Password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                    />
                  </Form.Group>
                  <Form.Group className="mb-4">
                    <Form.Control
                      type="password"
                      placeholder="Confirm New Password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                  </Form.Group>
                  <Button
                    className="w-100 mb-3"
                    onClick={handleChangePassword}
                  >
                    Change Password
                  </Button>
                </div>
              ) : (
                <>
                  <h2 className="text-center text-secondary fw-bold mb-5">
                    {type === "login" ? "Login" : type === "signup" ? "Signup" : "Forgot Password"}
                  </h2>
                  <Form ref={form} onSubmit={formik.handleSubmit} className="w-75">
                    {type === "signup" && (
                      <Form.Group className="mb-4">
                        <Form.Control
                          type="text"
                          name="name"
                          placeholder="Your Name"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.name}
                        />
                        {formik.touched.name && formik.errors.name && (
                          <div className="text-danger">{formik.errors.name}</div>
                        )}
                      </Form.Group>
                    )}

                    <Form.Group className="mb-4">
                      <Form.Control
                        type="email"
                        name="email"
                        placeholder="Your Email"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.email}
                      />
                      {formik.touched.email && formik.errors.email && (
                        <div className="text-danger">{formik.errors.email}</div>
                      )}
                    </Form.Group>

                    {type !== "forgot" && (
                      <Form.Group className="mb-4">
                        <Form.Control
                          type="password"
                          name="password"
                          placeholder="Password"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.password}
                        />
                        {formik.touched.password && formik.errors.password && (
                          <div className="text-danger">{formik.errors.password}</div>
                        )}
                      </Form.Group>
                    )}

                    <Button className="w-100 mb-3" type="submit">
                      {type === "login" ? "Login" : type === "signup" ? "Signup" : "Submit"}
                    </Button>

                    {type === "login" ? (
                      <>
                        <p className="text-danger text-center mb-0" style={{ cursor: "pointer" }} onClick={() => setType("forgot")}>
                          Forgot Password?
                        </p>
                        <p className="text-center" style={{ cursor: "pointer" }} onClick={() => setType("signup")}>
                          Create an account? Sign up
                        </p>
                      </>
                    ) : (
                      <p className="text-center" style={{ cursor: "pointer" }} onClick={() => setType("login")}>
                        Already have an account? Login
                      </p>
                    )}
                  </Form>
                </>
              )}
            </Col>

            <Col md={10} lg={6} className="order-1 order-lg-2 d-flex align-items-center">
              <Image
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp"
                fluid
                alt="Sample image"
              />
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default Signin;

