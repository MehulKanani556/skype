import React from 'react';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

function Productdetail(props) {
    const { category_id } = useParams();

    console.log(category_id);
    
    const category = useSelector(state => state.category);
    console.log(category.category);

    const product = useSelector(state => state.product);
    console.log(product.product);


    const category_details = category.category.find((v) => v.id === category_id);      

    console.log(category_details);
    return (
        <div>
            <p>{category_details.name}</p>
            <p>{category_details.description}</p>
            
        </div>
    );
}

export default Productdetail;