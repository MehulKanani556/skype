import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink, useParams } from "react-router-dom";
import { getProduct } from "../redux/slice/Product.slice";
import {
  addToCart,
  IncrementQty,
  DecrementQty,
} from "../redux/slice/Cart.slice";

import {
  Box,
  Rating,
  TextareaAutosize,
  TextField,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import { number, object, string } from "yup";
import {
  addReview,
  deleteReview,
  getReviews,
  updateReview,
} from "../redux/slice/Shopdetails.slice";

function Shopedetails(props) {
  const [count, setCount] = useState(1);
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const { item_id } = useParams();
  const [disabled, setDisabled] = useState(false);
  const [selectedReview, setSelectedReview] = useState(null);
  const [reviewData, setRevieWData] = useState([]);

  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart);

  console.log(item_id);
  const product = useSelector((state) => state.product);
  const Review = useSelector((state) => state.reviews);

  const getData = () => {
    dispatch(getProduct());
    dispatch(getReviews());

    const userHasReviewed = Review.reviews.map(
      (v) => v.userId === "1111" && v.productId === item_id
    );
    setDisabled(userHasReviewed); 
  };

  useEffect(() => {   
    getData();
  }, []); 

  const product_details = product.product.find((v) => v.id === item_id);

  const revieWData = Review.reviews.filter(
    (v) => v.productId === item_id && v.status === "active"
  );

  const handleIncrement = (id) => {
    const cartItem = cart.product.find((item) => item.id === id);
    if (cartItem) {
      dispatch(IncrementQty(id));
    } else {
      dispatch(addToCart({ ...product_details, quantity: 1 }));
    }
  };

  const handleDecrement = (id) => {
    dispatch(DecrementQty(id));
  };

  const handleCart = (id) => {
    dispatch(addToCart({ id, count }));
  };

  const handleUpdateReview = (review) => {
    console.log("Update review:", review);
    setSelectedReview(review);
    formik.setValues({
      name: review.name,
      email: review.email,
      review: review.review,
      rating: review.rating,
    });
    setDisabled(false);
  };

  const handleSubmit1 = async (values) => {
    const Data = {
      ...values,
      productId: item_id,
      userId: "1111",
      status: "pending",
    };

    dispatch(addReview(Data));
    setDisabled(true);
    alert("Your review is under process.");
  };

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      review: "",
      rating: 0,
    },
    validationSchema: object({
      name: string().required("Name is required"),
      email: string()
        .email("Invalid email address")
        .required("Email is required"),
      review: string().required("Review is required"),
      rating: number().required("Rating is required"),
    }),
    onSubmit: (values, { resetForm }) => {
      if (selectedReview) {
        dispatch(updateReview({ ...selectedReview, ...values }));
        alert("Your review is updated successfully.");
        setDisabled(true);

        const updatedReview = { ...selectedReview, ...values };
        const updatedReviews = reviewData.map((review) =>
          review.id === updatedReview.id ? updatedReview : review
        );
        setRevieWData(updatedReviews); 
      } else {
        handleSubmit1(values);
      }
      resetForm();
    },
  });

  const handleDeleteReview = (id) => {
    dispatch(deleteReview(id));
  };

  return (
    <div>
      <div className="container-fluid page-header py-5">
        <h1 className="text-center text-white display-6">Shop Detail</h1>
        <ol className="breadcrumb justify-content-center mb-0">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item active text-white">Shop Detail</li>
        </ol>
      </div>

      <div className="container-fluid py-5 mt-5">
        <div className="container py-5">
          <div className="row g-4 mb-5">
            <div className="col-lg-8 col-xl-9">
              <div className="row g-4">
                <div className="col-lg-6">
                  <div className="border rounded">
                    <a href="#">
                      <img
                        src="../img/allfruite.jpg"
                        className="img-fluid rounded"
                        alt="Image"
                      />
                    </a>
                  </div>
                </div>
                <div className="col-lg-6">
                  <h4 className="fw-bold mb-3">
                    {product_details.productName}
                  </h4>
                  <p className="mb-3">Category: Vegetables</p>
                  <h5 className="fw-bold mb-3">{product_details.price} $</h5>
                  <div className="d-flex mb-4">
                    <i className="fa fa-star text-secondary" />
                    <i className="fa fa-star text-secondary" />
                    <i className="fa fa-star text-secondary" />
                    <i className="fa fa-star text-secondary" />
                    <i className="fa fa-star" />
                  </div>
                  <p className="mb-4">{product_details.productDesc}</p>
                  <div
                    className="input-group quantity mb-5"
                    style={{ width: 100 }}
                  >
                    <div className="input-group-btn">
                      <button
                        className="btn btn-sm btn-minus rounded-circle bg-light border"
                        disabled={count === 1 ? true : false}
                        onClick={() => setCount((prevCount) => prevCount - 1)}
                      >
                        <i className="fa fa-minus" />
                      </button>
                    </div>
                    <input
                      type="text"
                      className="form-control form-control-sm text-center border-0  bg-transparent"
                      value={count}
                      readOnly
                    />
                    <div className="input-group-btn">
                      <button
                        className="btn btn-sm btn-plus rounded-circle bg-light border"
                        onClick={() => setCount((prevCount) => prevCount + 1)}
                      >
                        <i className="fa fa-plus" />
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCart(product_details.id)}
                    className="btn border border-secondary rounded-pill px-4 py-2 mb-4 text-primary"
                  >
                    Add to cart
                  </button>
                </div>
                <div className="col-lg-12">
                  <nav>
                    <div className="nav nav-tabs mb-3">
                      <button
                        className="nav-link active border-white border-bottom-0"
                        type="button"
                        role="tab"
                        id="nav-about-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#nav-about"
                        aria-controls="nav-about"
                        aria-selected="true"
                      >
                        Description
                      </button>
                      <button
                        className="nav-link border-white border-bottom-0"
                        type="button"
                        role="tab"
                        id="nav-mission-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#nav-mission"
                        aria-controls="nav-mission"
                        aria-selected="false"
                      >
                        Reviews
                      </button>
                    </div>
                  </nav>
                  <div className="tab-content mb-5">
                    <div
                      className="tab-pane active"
                      id="nav-about"
                      role="tabpanel"
                      aria-labelledby="nav-about-tab"
                    >
                      <p>{product_details.productDesc}</p>
                      <p>
                        Sabertooth peacock flounder; chain pickerel hatchetfish,
                        pencilfish snailfish filefish Antarctic icefish goldeye
                        aholehole trumpetfish pilot fish airbreathing catfish,
                        electric ray sweeper.
                      </p>
                      <div className="px-2">
                        <div className="row g-4">
                          <div className="col-6">
                            <div className="row bg-light align-items-center text-center justify-content-center py-2">
                              <div className="col-6">
                                <p className="mb-0">Weight</p>
                              </div>
                              <div className="col-6">
                                <p className="mb-0">1 kg</p>
                              </div>
                            </div>
                            <div className="row text-center align-items-center justify-content-center py-2">
                              <div className="col-6">
                                <p className="mb-0">Country of Origin</p>
                              </div>
                              <div className="col-6">
                                <p className="mb-0">Agro Farm</p>
                              </div>
                            </div>
                            <div className="row bg-light text-center align-items-center justify-content-center py-2">
                              <div className="col-6">
                                <p className="mb-0">Quality</p>
                              </div>
                              <div className="col-6">
                                <p className="mb-0">Organic</p>
                              </div>
                            </div>
                            <div className="row text-center align-items-center justify-content-center py-2">
                              <div className="col-6">
                                <p className="mb-0">Сheck</p>
                              </div>
                              <div className="col-6">
                                <p className="mb-0">Healthy</p>
                              </div>
                            </div>
                            <div className="row bg-light text-center align-items-center justify-content-center py-2">
                              <div className="col-6">
                                <p className="mb-0">Min Weight</p>
                              </div>
                              <div className="col-6">
                                <p className="mb-0">250 Kg</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      className="tab-pane"
                      id="nav-mission"
                      role="tabpanel"
                      aria-labelledby="nav-mission-tab"
                    >
                      <div>
                        {revieWData &&
                          revieWData.map((review) => (
                            <div key={review.id} className="d-flex mb-4">
                              <img
                                src="img/avatar.jpg"
                                className="img-fluid rounded-circle p-3"
                                style={{ width: 100, height: 100 }}
                                alt="User Avatar"
                              />
                              <div className="ms-3">
                                <p className="mb-2" style={{ fontSize: 14 }}>
                                  {new Date().toLocaleDateString()}
                                </p>
                                <div className="d-flex justify-content-between">
                                  <h5>{review.name}</h5>
                                  <div className="d-flex mb-3">
                                    {[...Array(5)].map((_, index) => (
                                      <i
                                        key={index}
                                        className={`fa fa-star ${
                                          index < review.rating
                                            ? "text-warning"
                                            : "text-secondary"
                                        }`}
                                      />
                                    ))}
                                  </div>
                                  {review.userId === "1111" ? (
                                    <div className="d-flex justify-content-end">
                                      <button
                                        className="btn btn-primary mr-2"
                                        onClick={() =>
                                          handleUpdateReview(review)
                                        }
                                      >
                                        Update
                                      </button>
                                      <button
                                        className="btn btn-danger"
                                        onClick={() =>
                                          handleDeleteReview(review.id)
                                        }
                                      >
                                        Delete
                                      </button>
                                    </div>
                                  ) : null}
                                </div>
                                <p>{review.review}</p>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                    <div className="tab-pane" id="nav-vision" role="tabpanel">
                      <p className="text-dark">
                        Tempor erat elitr rebum at clita. Diam dolor diam ipsum
                        et tempor sit. Aliqu diam amet diam et eos labore. 3
                      </p>
                      <p className="mb-0">
                        Diam dolor diam ipsum et tempor sit. Aliqu diam amet
                        diam et eos labore. Clita erat ipsum et lorem et sit
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <form onSubmit={formik.handleSubmit}>
                <h4 className="mb-5 fw-bold">Leave a Reply</h4>
                <div className="row g-4">
                  <div className="col-lg-6">
                    <TextField
                      type="text"
                      className="form-control border-0 me-4"
                      placeholder="Your Name *"
                      name="name"
                      value={formik.values.name}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={disabled}
                    />
                    {formik.touched.name && formik.errors.name ? (
                      <div className="text-danger">{formik.errors.name}</div>
                    ) : null}
                  </div>
                  <div className="col-lg-6">
                    <TextField
                      type="email"
                      className="form-control border-0"
                      placeholder="Your Email *"
                      name="email"
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={disabled}
                    />
                    {formik.touched.email && formik.errors.email ? (
                      <div className="text-danger">{formik.errors.email}</div>
                    ) : null}
                  </div>
                  <div className="col-lg-12">
                    <TextareaAutosize
                      name="review"
                      className="form-control border-0"
                      cols={30}
                      rows={8}
                      placeholder="Your Review *"
                      spellCheck="false"
                      value={formik.values.review}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={disabled}
                    />
                    {formik.touched.review && formik.errors.review ? (
                      <div className="text-danger">{formik.errors.review}</div>
                    ) : null}
                  </div>
                  <div className="col-lg-12">
                    <div className="d-flex justify-content-between py-3 mb-5">
                      <Box sx={{ "& > legend": { mt: 2 } }}>
                        <Typography component="legend">Rating</Typography>
                        <Rating
                          name="rating"
                          value={formik.values.rating}
                          disabled={disabled}
                          onChange={(event, newValue) => {
                            formik.setValues({
                              ...formik.values,
                              rating: newValue,
                            });
                          }}
                        />
                      </Box>
                      {formik.touched.rating && formik.errors.rating ? (
                        <div className="text-danger">
                          {formik.errors.rating}
                        </div>
                      ) : null}
                      <button
                        type="submit"
                        className="btn border border-secondary text-primary rounded-pill px-4 py-3"
                        disabled={disabled}
                      >
                        Post Comment
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div className="col-lg-4 col-xl-3">
              <div className="row g-4 fruite">
                <div className="col-lg-12">
                  <div className="input-group w-100 mx-auto d-flex mb-4">
                    <input
                      type="search"
                      className="form-control p-3"
                      placeholder="keywords"
                      aria-describedby="search-icon-1"
                    />
                    <span id="search-icon-1" className="input-group-text p-3">
                      <i className="fa fa-search" />
                    </span>
                  </div>
                  <div className="mb-4">
                    <h4>Categories</h4>
                    <ul className="list-unstyled fruite-categorie">
                      <li>
                        <div className="d-flex justify-content-between fruite-name">
                          <a href="#">
                            <i className="fas fa-apple-alt me-2" />
                            Apples
                          </a>
                          <span>(3)</span>
                        </div>
                      </li>
                      <li>
                        <div className="d-flex justify-content-between fruite-name">
                          <a href="#">
                            <i className="fas fa-apple-alt me-2" />
                            Oranges
                          </a>
                          <span>(5)</span>
                        </div>
                      </li>
                      <li>
                        <div className="d-flex justify-content-between fruite-name">
                          <a href="#">
                            <i className="fas fa-apple-alt me-2" />
                            Strawbery
                          </a>
                          <span>(2)</span>
                        </div>
                      </li>
                      <li>
                        <div className="d-flex justify-content-between fruite-name">
                          <a href="#">
                            <i className="fas fa-apple-alt me-2" />
                            Banana
                          </a>
                          <span>(8)</span>
                        </div>
                      </li>
                      <li>
                        <div className="d-flex justify-content-between fruite-name">
                          <a href="#">
                            <i className="fas fa-apple-alt me-2" />
                            Pumpkin
                          </a>
                          <span>(5)</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-12">
                  <h4 className="mb-4">Featured products</h4>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/fruite-item-3.jpg"
                        className="img-fluid rounded"
                        alt="Image"
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/featur-2.jpg"
                        className="img-fluid rounded"
                        alt
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/featur-3.jpg"
                        className="img-fluid rounded"
                        alt
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded me-4"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/vegetable-item-4.jpg"
                        className="img-fluid rounded"
                        alt
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded me-4"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/vegetable-item-5.jpg"
                        className="img-fluid rounded"
                        alt
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center justify-content-start">
                    <div
                      className="rounded me-4"
                      style={{ width: 100, height: 100 }}
                    >
                      <img
                        src="../img/vegetable-item-6.jpg"
                        className="img-fluid rounded"
                        alt
                      />
                    </div>
                    <div>
                      <h6 className="mb-2">Big Banana</h6>
                      <div className="d-flex mb-2">
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star text-secondary" />
                        <i className="fa fa-star" />
                      </div>
                      <div className="d-flex mb-2">
                        <h5 className="fw-bold me-2">2.99 $</h5>
                        <h5 className="text-danger text-decoration-line-through">
                          4.11 $
                        </h5>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex justify-content-center my-4">
                    <a
                      href="#"
                      className="btn border border-secondary px-4 py-3 rounded-pill text-primary w-100"
                    >
                      Vew More
                    </a>
                  </div>
                </div>
                <div className="col-lg-12">
                  <div className="position-relative">
                    <img
                      src="../img/banner-fruits.jpg"
                      className="img-fluid w-100 rounded"
                      alt
                    />
                    <div
                      className="position-absolute"
                      style={{
                        top: "50%",
                        right: 10,
                        transform: "translateY(-50%)",
                      }}
                    >
                      <h3 className="text-secondary fw-bold">
                        Fresh <br /> Fruits <br /> Banner
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <h1 className="fw-bold mb-0">Related products</h1>
        <div className="vesitable">
          <div className="owl-carousel vegetable-carousel justify-content-center">
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-6.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Parsely</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$4.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-1.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Parsely</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$4.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-3.png"
                  className="img-fluid w-100 rounded-top bg-light"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Banana</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-4.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Bell Papper</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-5.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Potatoes</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-6.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Parsely</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-5.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Potatoes</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
            <div className="border border-primary rounded position-relative vesitable-item">
              <div className="vesitable-img">
                <img
                  src="img/vegetable-item-6.jpg"
                  className="img-fluid w-100 rounded-top"
                  alt
                />
              </div>
              <div
                className="text-white bg-primary px-3 py-1 rounded position-absolute"
                style={{ top: 10, right: 10 }}
              >
                Vegetable
              </div>
              <div className="p-4 pb-0 rounded-bottom">
                <h4>Parsely</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit sed do
                  eiusmod te incididunt
                </p>
                <div className="d-flex justify-content-between flex-lg-wrap">
                  <p className="text-dark fs-5 fw-bold">$7.99 / kg</p>
                  <a
                    href="#"
                    className="btn border border-secondary rounded-pill px-3 py-1 mb-4 text-primary"
                  >
                    <i className="fa fa-shopping-bag me-2 text-primary" /> Add
                    to cart
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Single Product End */}
    </div>
  );
}

export default Shopedetails;
