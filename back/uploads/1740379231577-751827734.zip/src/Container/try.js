

import React, { useState } from "react";
import {
  Row,
  Col,
  Card,
  Form,
  Button,
  Image,
  Container,
} from "react-bootstrap";
import { object, string } from "yup";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { adduserdata, loginuser } from "../redux/slice/User.slice";
import { useNavigate } from "react-router-dom";

function Signin(props) {
  const [type, setType] = useState("login");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  let authSchema = {},
    initialValues = {};


  if (type === "login") {
    authSchema = object({
      email: string().email().required(),
      password: string().required(),
    });

    initialValues = {
      email: "",
      password: "",
    };
  } else if (type === "signup") {
    authSchema = object({
      name: string().required(),
      email: string().email().required(),
      password: string().required(),
    });

    initialValues = {
      name: "",
      email: "",
      password: "",
    };
  } else {
    initialValues = {
      email: "",
    };
    authSchema = object({
      email: string().email().required(),
    });
  }

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: authSchema,
    enableReinitialize: true,
    onSubmit: (values) => {
      if (type === "signup") {
        dispatch(adduserdata(values));
        console.log("signup success !!!");

        setType("login");

      } else {
        dispatch(loginuser({ values, navigate })).then((action) => {
          if (action.meta.requestStatus === "fulfilled") {
            console.log("Login success!");
            
            // navigate("/");
          } else {
            alert("Login failed !!!")
            console.log("Login failed:", action.payload);
          }
        });
      }
    },
  });

  const { handleBlur, handleChange, handleSubmit, errors, touched, values } = formik;

  return (
    <>
      <Container fluid className="mt-5">
        <Card
          className="text-black"
          style={{ borderRadius: "25px", marginTop: "200px" }}
        >
          <Card.Body>
            <Row className="align-items-center">
              <Col
                md={10}
                lg={6}
                className="order-2 order-lg-1 d-flex flex-column align-items-center text-center"
              >
                <h2 className="text-center text-secondary fw-bold mb-5">
                  {type === "login"
                    ? "Login"
                    : type === "signup"
                      ? "Signup"
                      : "Forgot Password"}
                </h2>

                <Form onSubmit={handleSubmit} className="w-75">
                  {/* Signup Form Field */}
                  {type === "signup" ? (
                    <div className="mb-4 d-flex align-items-center">
                      <label className="me-3" htmlFor="name">
                        <i className="fas fa-user"></i>
                      </label>
                      <Form.Control
                        className="w-100"
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Your Name"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.name}
                      />
                      {touched.name && errors.name ? (
                        <span>{errors.name}</span>
                      ) : null}
                    </div>
                  ) : null}

                  {/* Common Fields for Email */}
                  <div className="mb-4 d-flex align-items-center">
                    <label className="me-3" htmlFor="email">
                      <i className="fas fa-envelope"></i>
                    </label>
                    <Form.Control
                      className="w-100"
                      type="email"
                      id="email"
                      name="email"
                      placeholder="Your Email"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.email}
                    />
                    {touched.email && errors.email ? (
                      <span>{errors.email}</span>
                    ) : null}
                  </div>

                  {/* Password Field for Signup/Login */}
                  {type !== "forgot" ? (
                    <div className="mb-4 d-flex align-items-center">
                      <label className="me-3" htmlFor="password">
                        <i className="fas fa-lock"></i>
                      </label>
                      <Form.Control
                        className="w-100"
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Password"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.password}
                      />
                      {touched.password && errors.password ? (
                        <span>{errors.password}</span>
                      ) : null}
                    </div>
                  ) : null}

                  {/* Submit Button */}
                  <div className="text-center">
                    <Button className="mb-4" size="lg" type="submit">
                      <span className="text-white">
                        {type === "login"
                          ? "Login"
                          : type === "signup"
                            ? "Signup"
                            : "Submit"}
                      </span>
                    </Button>
                  </div>
                </Form>

                {/* Links to Switch Between Forms */}
                {type === "login" ? (
                  <>
                    <p
                      style={{ color: "red", cursor: "pointer" }}
                      onClick={() => setType("forgot")}
                    >
                      Forgot Password?
                    </p>
                    <p
                      style={{ cursor: "pointer" }}
                      onClick={() => setType("signup")}
                    >
                      Create an account? Sign up
                    </p>
                  </>
                ) : (
                  <p
                    style={{ cursor: "pointer" }}
                    onClick={() => setType("login")}
                  >
                    Already have an account? Login
                  </p>
                )}
              </Col>

              {/* Right Column with Image */}
              <Col
                md={10}
                lg={6}
                className="order-1 order-lg-2 d-flex align-items-center"
              >
                <Image
                  src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp"
                  fluid
                  rounded
                />
              </Col>
            </Row>
          </Card.Body>
        </Card>
      </Container>
    </>
  );
}

export default Signin;

