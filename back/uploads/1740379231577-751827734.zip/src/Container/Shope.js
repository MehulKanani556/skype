import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getCategory } from '../redux/slice/Category.slice';
import { NavLink } from 'react-router-dom';
import { getProduct } from '../redux/slice/Product.slice';
import { addToCart } from '../redux/slice/Cart.slice';
import { Box, Slider } from '@mui/material';

function Shope(props) {
    const dispatch = useDispatch();
    const [sortedProducts, setSortedProducts] = useState([]);
    const [search, setSearch] = useState('');
    const [sortOption, setSortOption] = useState('');
    const [selectedCat, setSelectedCat] = useState('');
    const [value, setValue] = useState([20, 299]);

    useEffect(() => {
        dispatch(getCategory());
        dispatch(getProduct());
    }, []);

    const category = useSelector(state => state.category);
    const product = useSelector(state => state.product);


    const handleAddToCart = (e, item) => {
        e.preventDefault();
        dispatch(addToCart({ id: item.id, count: 1 }));
    };

    const handleSearchAndSort = () => {

        const filteredProducts = product.product.filter(item =>
            (item.productName.toLowerCase().includes(search.toLowerCase()) ||
                item.productDesc.toLowerCase().includes(search.toLowerCase()) ||
                item.price.toString().includes(search)) &&
            item.price >= value[0] && item.price <= value[1] // Check if price  selected range
        );

        // Sort filtered products based on selected sort option
        const sortedProducts = filteredProducts.sort((a, b) => {
            if (sortOption === 'atz') {
                return a.productName.localeCompare(b.productName);
            } else if (sortOption === 'zta') {
                return b.productName.localeCompare(a.productName);
            } else if (sortOption === 'lth') {
                return a.price - b.price;
            } else if (sortOption === 'htl') {
                return b.price - a.price;
            }
            return 0; // No sorting
        });

        setSortedProducts(sortedProducts);
    };

    useEffect(() => {
        handleSearchAndSort();
    }, [search, sortOption, value, product.product]);

    const handleCat = (id) => {
        setSelectedCat(id);

        const fData = product.product.filter((v) => v.categoryid === id);

        setSortedProducts(fData.length > 0 ? fData : product.product);
    }

    // price for slider range :
    useEffect(() => {
        setSortedProducts(product.product);
    }, [product.product]);
    
    function valuetext(value) {
        return `${value}`;
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    

    return (
        <div>
            <div>
                {/* Single Page Header start */}
                <div className="container-fluid page-header py-5">
                    <h1 className="text-center text-white display-6">Shop</h1>
                    <ol className="breadcrumb justify-content-center mb-0">
                        <li className="breadcrumb-item"><a href="#">Home</a></li>
                        <li className="breadcrumb-item"><a href="#">Pages</a></li>
                        <li className="breadcrumb-item active text-white">Shop</li>
                    </ol>
                </div>
                {/* Single Page Header End */}
            </div>

            {/* Fruits Shop Start*/}
            <div className="container-fluid fruite py-5">
                <div className="container py-5">
                    <h1 className="mb-4">Fresh fruits shop</h1>
                    <div className="row g-4">
                        <div className="col-lg-12">
                            <div className="row g-4">
                                <div className="col-xl-3">
                                    <div className="input-group w-100 mx-auto d-flex">
                                        <input type="search" className="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1"
                                            value={search} onChange={(e) => { setSearch(e.target.value); handleSearchAndSort(); }} />
                                        <span id="search-icon-1" className="input-group-text p-3"><i className="fa fa-search" /></span>
                                    </div>
                                </div>
                                <div className="col-6" />
                                <div className="col-xl-3">
                                    <div className="bg-light ps-3 py-3 rounded d-flex justify-content-between mb-4">
                                        <label htmlFor="fruits">Default Sorting:</label>
                                        <select
                                            id="fruits"
                                            name="fruitlist"
                                            className="border-0 form-select-sm bg-light me-3"
                                            form="fruitform"
                                            onChange={(e) => { setSortOption(e.target.value); handleSearchAndSort(); }}
                                        >
                                            <option value="">Sort by</option>
                                            <option value="atz">A to Z</option>
                                            <option value="zta">Z to A</option>
                                            <option value="lth">Low to High</option>
                                            <option value="htl">High to Low</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div className="row g-4">
                                <div className="col-lg-3">
                                    <div className="row g-4">
                                        <div className="col-lg-12">
                                            <div className="mb-3">
                                                <h4>Categories</h4>
                                                <ul className="list-unstyled fruite-categorie">
                                                    {
                                                        category.category.map((v) => (
                                                            <li>
                                                                <div className="d-flex justify-content-between fruite-name">
                                                                    <a href='#' onClick={() => handleCat(v.id)}><i className="fas fa-apple-alt me-2" />{v.name}</a>
                                                                    <span>(3)</span>
                                                                </div>
                                                            </li>
                                                        ))
                                                    }
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="mb-3">
                                                <h4 className="mb-2">Price</h4>
                                                <Box sx={{ width: 300 }}>
                                                    <Slider
                                                        getAriaLabel={() => 'Price range'}
                                                        value={value}
                                                        onChange={handleChange}
                                                        valueLabelDisplay="auto"
                                                        getAriaValueText={valuetext}
                                                        min={0}
                                                        max={999}
                                                        sx={{ color: '#81c408' }}
                                                    />
                                                </Box>
                                                <output id="amount" name="amount" min-value={0} max-value={999} htmlFor="rangeInput">
                                                    {`Range: ${value[0]} - ${value[1]}`}
                                                </output>
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="mb-3">
                                                <h4>Additional</h4>
                                                <div className="mb-2">
                                                    <input type="radio" className="me-2" id="Categories-1" name="Categories-1" defaultValue="Beverages" />
                                                    <label htmlFor="Categories-1"> Organic</label>
                                                </div>
                                                <div className="mb-2">
                                                    <input type="radio" className="me-2" id="Categories-2" name="Categories-1" defaultValue="Beverages" />
                                                    <label htmlFor="Categories-2"> Fresh</label>
                                                </div>
                                                <div className="mb-2">
                                                    <input type="radio" className="me-2" id="Categories-3" name="Categories-1" defaultValue="Beverages" />
                                                    <label htmlFor="Categories-3"> Sales</label>
                                                </div>
                                                <div className="mb-2">
                                                    <input type="radio" className="me-2" id="Categories-4" name="Categories-1" defaultValue="Beverages" />
                                                    <label htmlFor="Categories-4"> Discount</label>
                                                </div>
                                                <div className="mb-2">
                                                    <input type="radio" className="me-2" id="Categories-5" name="Categories-1" defaultValue="Beverages" />
                                                    <label htmlFor="Categories-5"> Expired</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <h4 className="mb-3">Featured products</h4>
                                            <div className="d-flex align-items-center justify-content-start">
                                                <div className="rounded me-4" style={{ width: 100, height: 100 }}>
                                                    <img src="img/featur-1.jpg" className="img-fluid rounded" alt />
                                                </div>
                                                <div>
                                                    <h6 className="mb-2">Big Banana</h6>
                                                    <div className="d-flex mb-2">
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star" />
                                                    </div>
                                                    <div className="d-flex mb-2">
                                                        <h5 className="fw-bold me-2">2.99 $</h5>
                                                        <h5 className="text-danger text-decoration-line-through">4.11 $</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex align-items-center justify-content-start">
                                                <div className="rounded me-4" style={{ width: 100, height: 100 }}>
                                                    <img src="img/featur-2.jpg" className="img-fluid rounded" alt />
                                                </div>
                                                <div>
                                                    <h6 className="mb-2">Big Banana</h6>
                                                    <div className="d-flex mb-2">
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star" />
                                                    </div>
                                                    <div className="d-flex mb-2">
                                                        <h5 className="fw-bold me-2">2.99 $</h5>
                                                        <h5 className="text-danger text-decoration-line-through">4.11 $</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex align-items-center justify-content-start">
                                                <div className="rounded me-4" style={{ width: 100, height: 100 }}>
                                                    <img src="img/featur-3.jpg" className="img-fluid rounded" alt />
                                                </div>
                                                <div>
                                                    <h6 className="mb-2">Big Banana</h6>
                                                    <div className="d-flex mb-2">
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star text-secondary" />
                                                        <i className="fa fa-star" />
                                                    </div>
                                                    <div className="d-flex mb-2">
                                                        <h5 className="fw-bold me-2">2.99 $</h5>
                                                        <h5 className="text-danger text-decoration-line-through">4.11 $</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex justify-content-center my-4">
                                                <a href="#" className="btn border border-secondary px-4 py-3 rounded-pill text-primary w-100">Vew More</a>
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="position-relative">
                                                <img src="img/banner-fruits.jpg" className="img-fluid w-100 rounded" alt />
                                                <div className="position-absolute" style={{ top: '50%', right: 10, transform: 'translateY(-50%)' }}>
                                                    <h3 className="text-secondary fw-bold">Fresh <br /> Fruits <br /> Banner</h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-9">
                                    <div className="row g-4 justify-content-center">
                                        {
                                            sortedProducts.map((item) => (
                                                <div key={item.id} className="col-md-6 col-lg-6 col-xl-4">
                                                    <NavLink to={'/shopedetails/' + item.id}>
                                                        <div className="rounded position-relative fruite-item">
                                                            <div className="fruite-img">
                                                                <img src="img/fruite-item-5.jpg" className="img-fluid w-100 rounded-top" alt />
                                                            </div>
                                                            <div className="text-white bg-secondary px-3 py-1 rounded position-absolute" style={{ top: 10, left: 10 }}>Fruits</div>
                                                            <div className="p-4 border border-secondary border-top-0 rounded-bottom">
                                                                <h4>{item.productName}</h4>
                                                                <p>{item.productDesc}</p>
                                                                <div className="d-flex justify-content-between flex-lg-wrap">
                                                                    <p className="text-dark fs-5 fw-bold mb-0">$ {item.price} </p>
                                                                    <button className="btn border border-secondary rounded-pill px-3 text-primary" onClick={(e) => handleAddToCart(e, item)}>
                                                                        <i className="fa fa-shopping-bag me-2 text-primary" /> Add to cart
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </NavLink>
                                                </div>
                                            ))
                                        }
                                        <div className="col-12">
                                            <div className="pagination d-flex justify-content-center mt-5">
                                                <a href="#" className="rounded">«</a>
                                                <a href="#" className="active rounded">1</a>
                                                <a href="#" className="rounded">2</a>
                                                <a href="#" className="rounded">3</a>
                                                <a href="#" className="rounded">4</a>
                                                <a href="#" className="rounded">5</a>
                                                <a href="#" className="rounded">6</a>
                                                <a href="#" className="rounded">»</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Fruits Shop End*/}</div>

    );
}

export default Shope;