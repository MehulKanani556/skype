import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getcheck } from '../redux/slice/Checkout.slice';
import { getProduct } from '../redux/slice/Product.slice';
import { useNavigate } from 'react-router-dom';
import imageurl from "../img/d1.jpg"

function Order() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const Orders = useSelector((state) => state.checkout.checkout);
    const products = useSelector((state) => state.product.product);

    useEffect(() => {
        dispatch(getProduct());
    }, [dispatch]);

    const fetchOrders = () => {
        dispatch(getcheck());
    };

    const handleShowDetails = (orderId) => {
        navigate(`/orderdetails/${orderId}`);
    };

    return (
        <div>
            {/* Single Page Header start */}
            <div className="container-fluid page-header py-5 bg-primary text-white">
                <h1 className="text-center text-white display-6">My Orders</h1>
                <ol className="breadcrumb justify-content-center mb-0">
                    <li className="breadcrumb-item">
                        <a href="#" className="text-white">Home</a>
                    </li>
                    <li className="breadcrumb-item">
                        <a href="#" className="text-white">Pages</a>
                    </li>
                    <li className="breadcrumb-item text-white active">Orders</li>
                </ol>    
            </div>
            {/* Single Page Header End */}

            {/* Cart Page Start */}
            <div className="container-fluid py-5">
                <div className="container">
                    <button
                        type="button"
                        className="btn btn-outline-primary mb-4"
                        onClick={fetchOrders}
                    >
                        My Orders
                    </button>
                    <div className="row">
                        {Orders.length > 0 ? Orders.map((order) => (
                            <div key={order.id} className="col-md-4 mb-4">
                                <div className="card border-primary shadow-sm">
                                    <div className="card-body">
                                        <h5 className="card-title text-primary">Order ID: {order.id}</h5>
                                        <h6 className="card-subtitle mb-2 text-muted">Billing Details</h6>
                                        <p><strong>Total Amount:</strong> ${order.total_amt}</p>
                                        <h6 className="card-subtitle mb-2 text-muted">Products</h6>
                                        {order.cart && order.cart.length > 0 ? order.cart.map((cartItem) => {
                                            const product = products.find((p) => p.id === cartItem.pid);
                                            return product ? (
                                                <div key={cartItem.pid} className="card mb-3">
                                                    <div className="row g-0">
                                                        <div className="col-md-4 my-auto">
                                                            <img src={imageurl} alt={product.productName} className="img-fluid" />
                                                        </div>
                                                        <div className="col-md-8">
                                                            <div className="card-body">
                                                                <h6 className="card-title text-primary fw-bold">{product.productName}</h6>
                                                                <p className="card-text"><small className=""><strong>Discrition:</strong> {product.productDesc}</small></p>
                                                                <p className="card-text mb-0">
                                                                   <strong>Qty:</strong>  {cartItem.qty} <br/> <strong>Price:</strong> ${product.price}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ) : null;
                                        }) : <p>No items in this order.</p>}
                                    </div>
                                        <button className="btn btn-outline-primary" onClick={() => handleShowDetails(order.id)}>Show Details</button>
                                </div>
                            </div>
                        )) : <p>No orders available.</p>}
                    </div>
                </div>
            </div>
            {/* Cart Page End */}
        </div>
    );
}

export default Order;
