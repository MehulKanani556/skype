// src/Container/OrderDetail.js
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { getcheck } from '../redux/slice/Checkout.slice';
import { getProduct } from '../redux/slice/Product.slice';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';

// Static image URL (replace with your actual image path)
const staticImageUrl = "https://via.placeholder.com/150/81c408/fff"; // Placeholder image

function OrderDetail() {
    const { orderId } = useParams();
    const [orderDetails, setOrderDetails] = useState(null);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const Orders = useSelector((state) => state.checkout.checkout);

    const products = useSelector((state) => state.product.product);
    console.log(products)

    useEffect(() => {
        dispatch(getProduct())
    }, []);

    useEffect(() => {
        dispatch(getcheck());
    }, [dispatch]);

    useEffect(() => {
        const matchedOrder = Orders.find(order => order.id === orderId);
        if (matchedOrder) {
            setOrderDetails(matchedOrder);
        }
    }, [Orders, orderId]);

    const handleIconClick = () => {
        navigate('/order');
    };


    if (orderDetails) {
        return (
            <div className="container mt-5">
                <div className="text-center mb-4" style={{ marginTop: "12rem" }}>
                    <h1 className="display-4 text-primary">Order Details</h1>
                    <p className="lead text-muted">Here are the details of your order.</p>
                </div>
                <div className="card shadow-lg border-light">

                    <div className="card-header d-flex justify-content-around align-items-center bg-primary text-white">
                        <span onClick={handleIconClick} style={{ cursor: 'pointer' }}>
                            <KeyboardDoubleArrowLeftIcon />
                        </span>
                        <h5 className="mb-0 fw-bold fs-3 text-white">Order ID: <span className="text-light">{orderDetails.id}</span></h5>
                        <h6 className="card-subtitle fw-bold fs-3 text-white">Status: {orderDetails.Status}</h6>
                    </div>
                    <div className="card-body">
                        <h2 className="mt-4">Products</h2>
                        <div className="row">
                            {orderDetails.cart.map((item, index) => {
                                // Find the product details based on the product ID
                                const product = products.find(product => product.id === item.pid);
                                return (
                                    <div className="col-md-4 mb-3" key={index}>
                                        <div className="card border-primary d-flex flex-row align-items-center">
                                            <div className='mx-2'> <img src={staticImageUrl} className="bg-primary" alt={product ? product.productName : "Product Image"} /></div>
                                            <div className="card-body">
                                                <h5 className="card-title text-primary">{product ? product.productName : "Product Name"}</h5>
                                                <p className="card-text"><strong>Description:</strong> {product ? product.productDesc : "No description available."}</p>
                                                <p className="card-text"><strong>Price:</strong> ${product ? product.price : "0.00"}</p>
                                                <p className="card-text"><strong>Quantity:</strong> {item.qty}</p>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        <h2 className="mt-4">Billing Details</h2>
                        <div className="row">
                            <div className="col-md-6">
                                <ul className="list-group">
                                    <li className="list-group-item"><strong>Name:</strong> {orderDetails.billing_details.name}</li>
                                    <li className="list-group-item"><strong>Last Name:</strong> {orderDetails.billing_details.lastname}</li>
                                    <li className="list-group-item"><strong>Address:</strong> {orderDetails.billing_details.address}</li>
                                    <li className="list-group-item"><strong>City:</strong> {orderDetails.billing_details.city}</li>
                                    <li className="list-group-item"><strong>Country:</strong> {orderDetails.billing_details.country}</li>
                                </ul>
                            </div>
                            <div className="col-md-6">
                                <ul className="list-group">
                                    <li className="list-group-item"><strong>Pincode:</strong> {orderDetails.billing_details.pincode}</li>
                                    <li className="list-group-item"><strong>Mobile Number:</strong> {orderDetails.billing_details.mobileNumber}</li>
                                    <li className="list-group-item"><strong>Email:</strong> {orderDetails.billing_details.email}</li>
                                    <li className="list-group-item"><strong>Delivery:</strong> {orderDetails.billing_details.Delivery ? 'cod' : 'No'}</li>                                   
                                </ul>
                            </div>
                        </div>



                        <div className="text-end mt-4">
                            <button type='button' className='btn btn-primary text-white'>
                                Total Amount: ${orderDetails.total_amt}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return <p className="text-center mt-5">No order details found.</p>;
}

export default OrderDetail;