import { useReducer } from "react";
import { createContext } from "react";
import { THEME_CHANGE } from "./ActionTypes";
import { ThemeReducer } from "./reducer/theme.reducer";

export const Themecontex = createContext();

const initialstate = {
    theme: 'light'
}

export const Themeprovider = ({ children }) => {
    const [state, dispatch] = useReducer(ThemeReducer, initialstate);
    

    const changeTheme = (oldTheme) => {
        const newTheme = oldTheme === 'light' ? 'dark' : 'light';

        dispatch({ type: THEME_CHANGE, payload: newTheme });
    }   

    return (
        <Themecontex.Provider
            value={{
                ...state,
                changeTheme
            }}
        >
            {children}
        </Themecontex.Provider>
    )
}