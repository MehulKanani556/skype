import { THEME_CHANGE } from "../ActionTypes";

export const ThemeReducer = (state,action) => {
    switch (action.type) {
        case THEME_CHANGE:
            
           return{
            theme : action.payload
           }
    
        default:
            return state;
    }
}