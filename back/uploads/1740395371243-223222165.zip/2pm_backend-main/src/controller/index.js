module.exports.categoryController = require("./categories.controller");
module.exports.salespeopleController = require("./salespeople.controller");
module.exports.usersController = require("./users.controller");