const { Server } = require('socket.io');

const conectChat = () => {
    const io = new Server({
        cors: {
            origin: "http://localhost:3000"
        }
    });

    io.on('connection', (socket) => {
        console.log('a user connected', socket.id);

        socket.emit("welcome", "Welcome to fruitbles.")

        socket.broadcast.emit("greeting", "Hello all");

        socket.on("message", (data) => {
            console.log(data);

            io.to(data.rec).emit("rec-msg", data.msg);
            
        });

        socket.on("join-group", (group) =>{
            socket.join(group);
        })
    });

    io.listen(4000);
}

module.exports = conectChat;